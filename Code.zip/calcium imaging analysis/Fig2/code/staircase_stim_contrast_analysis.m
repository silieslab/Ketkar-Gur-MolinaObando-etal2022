%% Change this variable to your data path
clear all
close all
datapath='/Volumes/Backup Plus/PhD_Archive/Data_analysis_ongoing/Matlab_pData';
addpath(genpath((datapath)));
cd(datapath);

%% Load data
% l2_dataa = load('L2_staircase_contrast.mat');
l2_dataa = load('L2_staircase_contrast_norm_traces.mat');
l2_data = l2_dataa.data.epoch_step_response(:,3:end);
% l1_dataa = load('L1_staircase_contrast.mat');
l1_dataa = load('L1_staircase_contrast_norm_traces.mat');
l1_data = l1_dataa.data.epoch_step_response(:,3:end);
%% Fit
luminance_values = [0 0.25 0.5 0.75 1 0.75 0.5 0.25 0];
after_luminance = circshift(luminance_values,-1);
weber_contrast = lumToContValue(luminance_values,after_luminance,'Weber');
c = weber_contrast(2:8);


fit_contrasts = c(4:end);
l1_fit_data = l1_data(:,4:end);
l2_fit_data = l2_data(:,4:end);


%% Fly based 


[l2_mi_x,l2_mi_m,l2_mi_e] = mean_cat_full(l2_fit_data./max(l2_fit_data,[],2),1,l2_dataa.data.currFlyIDs);
[l1_mi_x,l1_mi_m,l1_mi_e] = mean_cat_full(l1_fit_data./max(l1_fit_data,[],2),1,l1_dataa.data.currFlyIDs);

[nn_l2_mi_x,nn_l2_mi_m,nn_l2_mi_e] = mean_cat_full(l2_fit_data,1,l2_dataa.data.currFlyIDs);
[nn_l1_mi_x,nn_l1_mi_m,nn_l1_mi_e] = mean_cat_full(l1_fit_data,1,l1_dataa.data.currFlyIDs);

aa = [0 nn_l1_mi_m]
bb = [0 nn_l2_mi_m]
cc =  [0 fit_contrasts]

e1 = errorbar(fit_contrasts,nn_l1_mi_m,nn_l1_mi_e,'-o')
hold on;
e2 = errorbar(fit_contrasts,nn_l2_mi_m,nn_l2_mi_e,'-o')
ylim([0, 0.6])
xlim([-1.2 0])

%% With bootstrapping with replacement 50 times
bootstrap_n = 50;
% sample_size = 5; 


l1_gofs = zeros(bootstrap_n,1);
l1_params_k = zeros(bootstrap_n,1);
l1_params_a = zeros(bootstrap_n,1);
l1_id = ceil(rand(size(nn_l1_mi_x,1),bootstrap_n)*size(nn_l1_mi_x,1));
for i = 1:bootstrap_n
    
    curr_fit_data = mean(nn_l1_mi_x(l1_id(:,i),:));
%     [xData, yData] = prepareCurveData( fit_contrasts, curr_fit_data );
    [xData, yData] = prepareCurveData( [0 fit_contrasts], [0 curr_fit_data] );
    % Set up fittype and options.
    ft = fittype( 'a* ((1 + exp(k*x))^-1 - 1/2)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.StartPoint = [0.957166948242946 0.485375648722841];

    % Fit model to data.
    [fitresult, gof] = fit( xData, yData, ft, opts );
    
 
    if gof.adjrsquare < 0.6
        k = nan;
        a = nan;
    else
        k = fitresult.k;
        a = fitresult.a;
    end
    l1_params_k(i) = k;
    l1_gofs(i) = gof.adjrsquare;
    l1_params_a(i) = a;
    % Plot fit with data.
%     close all
%     figure( 'Name', 'untitled fit 1' );
%     plot( fitresult, [xData; 0], [yData; fitresult(0)]);
%     % Label axes
%     xlabel( 'ex_c', 'Interpreter', 'none' );
%     ylabel( 'ex_data', 'Interpreter', 'none' );
%     grid on
%     title(sprintf("k: %.2f - a: %.2f - gof: %.2f",fitresult.k,fitresult.a, gof.adjrsquare))
%     xlim([-1.1,0])
%     ylim([0, 0.6])
%     a = gca;
%     ylim([0,a.YLim(2)+a.YLim(2)*0.1])
%     waitforbuttonpress
%     
    
    
end

l2_gofs = zeros(bootstrap_n,1);
l2_params_k = zeros(bootstrap_n,1);
l2_params_a = zeros(bootstrap_n,1);
l2_id = ceil(rand(size(nn_l1_mi_x,1),bootstrap_n)*size(nn_l1_mi_x,1));
for i = 1:bootstrap_n
    
    curr_fit_data = mean(nn_l2_mi_x(l2_id(:,i),:));
%     [xData, yData] = prepareCurveData( fit_contrasts, curr_fit_data );
    [xData, yData] = prepareCurveData( [0 fit_contrasts], [0 curr_fit_data] );

    % Set up fittype and options.
    ft = fittype( 'a* ((1 + exp(k*x))^-1 - 1/2)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.StartPoint = [0.957166948242946 0.485375648722841];

    % Fit model to data.
    [fitresult, gof] = fit( xData, yData, ft, opts );
    
    if gof.adjrsquare < 0.6
        k = nan;
        a = nan;
    else
        k = fitresult.k;
        a = fitresult.a;
    end
    l2_params_k(i) = k;
    l2_params_a(i) = a;
    l2_gofs(i) = gof.adjrsquare;
    % Plot fit with data.
%     close all
%     figure( 'Name', 'untitled fit 1' );
%     plot( fitresult, [xData; 0], [yData; fitresult(0)]);
%     % Label axes
%     xlabel( 'ex_c', 'Interpreter', 'none' );
%     ylabel( 'ex_data', 'Interpreter', 'none' );
%     grid on
%     title(sprintf("k: %.2f - a: %.2f - gof: %.2f",fitresult.k,fitresult.a, gof.adjrsquare))
%     xlim([-1.1,0])
%     ylim([0, 0.6])
%     a = gca;
%     ylim([0,a.YLim(2)+a.YLim(2)*0.1])
%     waitforbuttonpress

    
    
    
end

%k
data = [l1_params_k;l2_params_k];

group = [ones(length(l1_params_k),1) ;ones(length(l2_params_k),1)*2];

[l1_lillie,p] = lillietest(l1_params_k)
[l2_lillie,p] = lillietest(l2_params_k)

% pd_l1 = fitdist(l1_params_k,'Normal');
% pd_l2 = fitdist(l2_params_k,'Normal');
% 
% ci_l1 = paramci(pd_l1);
% ci_l2 = paramci(pd_l2);
% 
% figure(1)
% x = [2:.1:11];
% y1 = normpdf(x,pd_l1.mu,pd_l1.sigma);
% y2 = normpdf(x,pd_l2.mu,pd_l2.sigma);
% 
% plot(x,y1)
% hold on
% plot(x,y2)

[h,p]=ttest2(l1_params_k,l2_params_k);

figure(2)
boxplot(data,group,'Notch','on','Labels',{'L1','L2'})
ylabel('k (slope of sigmoidal))')
title(sprintf("ttest: %.5f",p))

figure(2)

% a
data = [l1_params_a;l2_params_a];

group = [ones(length(l1_params_a),1) ;ones(length(l2_params_a),1)*2];

[l1_lillie,p] = lillietest(l1_params_a)
[l2_lillie,p] = lillietest(l2_params_a)

[h,p]=ttest2(l1_params_a,l2_params_a);

figure(3)
boxplot(data,group,'Notch','on','Labels',{'L1','L2'})
ylabel('a')
title(sprintf("ttest: %.5f",p))






  
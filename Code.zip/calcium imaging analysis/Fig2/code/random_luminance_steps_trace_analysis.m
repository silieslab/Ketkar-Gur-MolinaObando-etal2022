%% Script for analyzing the pData and saving for post-processing
clear all;
close all;
clc;

% Change this variable to your pData path
pdatapath='/Volumes/Backup Plus/PhD_Archive/Data_analysis_ongoing/Matlab_pData';
addpath(genpath((pdatapath)));
cd(pdatapath);

database_select_samples_bg;
gen_str = 'L1';
options.GroupType = 'L2' % Has to be 'L3' for L3 and 'L2' for L2 but you don't need this for L1
options=[]
%% Processing Data 
% -- PAPER below genotypes
% L1
data_indices = find(i_fff_05steps_10sONgrayOFF.*i_L1_c202_Gal4_x_Chr2_UAS_GC6f.*i_No_toxin.*~i_moving);

%L2 and L3
% Change options.GroupType to "L2" or "L3"
% data_indices = find(i_fff_05steps_10sONgrayOFF.*i_L3MH56Gal4_L221DhhGal4_UAS_GCaMP6f.*i_exp_L2_L3_PTX.*i_No_toxin.*~i_moving);


% create structures by neuron
data_structs = create_neuron_structure_all_bg(data_indices);

% load all the data!
pre_processed_data = load_neuron_data10Hz_ks_for_bg(data_structs,pdatapath,options);

% This function groups the different interesting epoch combinations in a
% Matrix, stored in combination_storage
processed_data = aggregate_5LumSteps_Rand_v1(pre_processed_data);
%% Analyze
corr_t = 0 % Correlation threshold
useNegCorr = true; % Bool to use the above threshold to filter ROIs

numROIs = size(processed_data.responses,1);

% Luminance values measured from Investigator @ gottingen
vals = [0,0.25,0.5,0.75,1];
candelas= [0.005, 0.644, 1.280, 1.915, 2.600];
luminances= [ 414.92584274,  53442.44854442, 106221.01574046, 158916.59776796,215761.43822281];
   
luminances = [0,0.25,0.5,0.75,1]; % For plotting we use normalized values
   
responses = processed_data.responses;

negative_correlated = zeros(numROIs,1);
positive_correlated = zeros(numROIs,1);

roi_corr = zeros(numROIs,1);
% Check which cells are positively or negatively correlated
for iROI=1:numROIs
    
    resp = max(squeeze(responses(iROI,:,:)),[],2);
    
    
    roi_corr(iROI) = corr(resp,luminances');
    
end
baseline_resp = (mean(responses(:,:,90:100),3) - min(min(responses(:,:,:),[],3),[],2))./ ...
    (max(max(responses(:,:,:),[],3),[],2) - min(min(responses(:,:,:),[],3),[],2));


% baseline_resp = mean(responses(:,:,90:100),3)./ ...
%     max(max(responses(:,:,:),[],3),[],2)

mi = calculate_MI_L1_paper(processed_data);

nl_vals = zeros(numROIs,1);
gof_lin_fit = zeros(numROIs,1);
gof_nl_fit = zeros(numROIs,1);

pearson_corr = zeros(numROIs,1);
spearman_corr = zeros(numROIs,1);
% Non linearity calculation
for iROI=1:numROIs
    
    % Correlations - to compute the difference later on for getting an
    % index of non-linearity
    pearson_corr(iROI) = corr(luminances',baseline_resp(iROI,:)','Type','Pearson');
    spearman_corr(iROI) = corr(luminances',baseline_resp(iROI,:)','Type','Spearman');


    % Another non-linearity index, not used in the paper but gives the same
    % conclusions for L1 and L3 neurons
    xp = linspace(0, 1, 100);
    [xData, yData] = prepareCurveData( luminances, baseline_resp(iROI,:) );
    
    % Lin fit
    lin_fit = fittype( 'poly1' );
    [fitresult_lin, gof_lin] = fit( xData, yData, lin_fit );
    gof_lin_fit(iROI) = gof_lin.rsquare;
    
    % NL fit
    nl_fit = fittype( 'poly2' );
    [fitresult_nl, gof_nl] = fit( xData, yData, nl_fit );
    
    gof_nl_fit(iROI) = gof_nl.rsquare;
    
    nl_vals(iROI) = sqrt(sum(square((fitresult_nl(xp) - fitresult_lin(xp)))));

    

end


if useNegCorr
%     conditional = (roi_corr<corr_t) & (gof_lin_fit>0.5);
    conditional = (roi_corr<corr_t) ;
    selected_resps = baseline_resp(conditional, :,:);
    selected_flyIDs = processed_data.flyID(conditional);
    selected_mi = mi(conditional);
    selected_nl = nl_vals(conditional);
    
    selected_pearson = pearson_corr(conditional);
    selected_spearman = spearman_corr(conditional);
    
    selected_gof_nl_fit = gof_nl_fit(conditional);
    selected_gof_lin_fit = gof_lin_fit(conditional);
elseif usePosCorr
    selected_resps = baseline_resp(roi_corr>corr_t, :,:);
    selected_flyIDs = processed_data.flyID(roi_corr>corr_t);
    selected_mi = mi(roi_corr>corr_t);
    selected_nl = nl_vals(roi_corr>corr_t);
else
    selected_resps = baseline_resp;
    selected_flyIDs = processed_data.flyID;
    selected_mi = mi;
    selected_nl = nl_vals;
end

[baseline_x,baseline_m,baseline_e] = mean_cat_full(selected_resps,1,selected_flyIDs);

[lin_gof_x,lin_gof_m,lin_gof_e] = mean_cat_full(selected_gof_lin_fit,1,selected_flyIDs);
[nl_gof_x,nl_gof_m,nl_gof_e] = mean_cat_full(selected_gof_nl_fit,1,selected_flyIDs);
[nl_x,nl_m,nl_e] = mean_cat_full(selected_nl,1,selected_flyIDs);

[pearson_x,pearson_m,pearson_e] = mean_cat_full(selected_pearson,1,selected_flyIDs);
[spearman_x,spearman_m,spearman_e] = mean_cat_full(selected_spearman,1,selected_flyIDs);

%% Save for post-analysis
% No need to use this part. The data is already saved:
% "L1_5steps_BurakData.mat"
% "L2_5steps_BurakData.mat"
% "L3_5steps_BurakData.mat"
data.responses = selected_resps;
data.experimentID = selected_flyIDs;
data.genotypes = repmat({'L1'},size(selected_flyIDs,2),1); % Change the name
data.luminances = luminances;
data.nl = selected_nl;
data.gof_lin = selected_gof_lin_fit;
data.gof_nl = selected_gof_nl_fit;
data.pearson_c = selected_pearson;
data.spearman_c = selected_spearman;

data.mi = selected_mi;
save("L1_5steps_BurakData.mat","data") %Change the name depending on the neuron





%% Analysis and plots of staircase stimulus
clc;
clear all;
close all;


% Pre-defined parameters
numberOfGroups = 1;
options.interpolation_rate = 10;
% Change this variable to your data path
datapath='/Volumes/Backup Plus/PhD_Archive/Data_analysis_ongoing/Matlab_pData';
addpath(genpath((datapath)));
cd(datapath);

colorss = {[27/256 158/256 119/256] ; [179/256 226/256 205/256];...
            [152/256 78/256 163/256]; [222/256 203/256 228/256]};

%% Load data
% Choose the data of interest
% L3_staircaseStim.mat - L2_staircaseStim.mat - L1_staircaseStim.mat
loaded_d = load('L1_staircaseStim.mat');
data = loaded_d.data;

currFlyIDs = data.flyIDs;
flyIDs{1} = data.flyIDs;
flyNumbers(1) = length(unique(currFlyIDs));
ROInum(1) = length(currFlyIDs);

responses{1} = data.responses;


[fly_resp{1},fly_mean{1},fly_err{1}]...
    = mean_cat_full(data.responses,1,currFlyIDs);

gen_str{1} = data.gen_str;
stimulus{1} = data.stimulus;
%% Plotting raw data
% Arranging stimulus

for i = 1: numberOfGroups
    % Figure properties
    f1 = figure('Color','w');
    genotypeName = sprintf([char(gen_str{i}) ', N: %d ( %d )'],flyNumbers(i),ROInum(i));
    f1.Name = genotypeName;
    
    
    % Subplot1 all ROIs
    subplot(2,1,1)
    plotTraces = responses{i};
    im = imagesc(plotTraces);
    titleStr = sprintf([char(gen_str{i}) ', N: %d ( %d )'],flyNumbers(i),ROInum(i));
    title(['All ROIs, ' titleStr]);
    
    c = colorbar; % enable colorbar
    c.Label.String = 'dF/F';
    xlabel('Time')
    ylabel('ROI number')
    
    subplot(2,1,2)
    % Stimulus conversion
    stimTrace = stimulus{i};
    stimTrace(find(stimTrace==5)) = 3;
    stimTrace(find(stimTrace==6)) = 2;
    stimTrace(find(stimTrace==7)) = 1;
    stimTrace(find(stimTrace==8)) = 0;
    plot(responses{i}','LineWidth',0.5,'Color',[0 0 0 0.3])
    hold on;
    plot(mean(responses{i}),'LineWidth',2);
    plot(stimTrace/2,'LineWidth',2);
    xlabel('Time')
    ylabel('dF/F')
    
end
    

%% Compact plot
figure('Color','w')
iColor=1;
for i = 1: numberOfGroups
    % Figure properties
    
    genotypeName = sprintf([char(gen_str{i}) ', N: %d ( %d )'],flyNumbers(i),ROInum(i));
   
    % Subplot1 all ROIs
    subplot(numberOfGroups,1,i)
    
    % Stimulus conversion
    stimTrace = stimulus{i};
    stimTrace(find(stimTrace==5)) = 3;
    stimTrace(find(stimTrace==6)) = 2;
    stimTrace(find(stimTrace==7)) = 1;
    stimTrace(find(stimTrace==8)) = 0;
    
    maxVal = max(max(responses{i}));
    plot(responses{i}','LineWidth',0.5,'Color',[0 0 0 0.1])
    hold on;
    plot(mean(responses{i}),'LineWidth',3,'DisplayName',genotypeName,'Color',colorss{iColor});
    
    plot((stimTrace/max(stimTrace))*maxVal,'LineWidth',1,'DisplayName','Stimulus','Color','k');
    
    pCorr = corr(stimTrace',mean(responses{i})');
    title(sprintf('%s, Pearsons corr: %.2f', genotypeName,pCorr))
    
    xlabel('Time')
    ylabel('dF/F')
    iColor = iColor+2;
    
end

%% Correlation analysis
BP_corr_fly = [];
labels_corr_fly = [];

BP_corr_ROI = [];
labels_corr_ROI = [];
for currGroup = 1: numberOfGroups
    clear pCorr currResp stimTrace
    
    currResp = responses{currGroup};
    stimTrace = stimulus{currGroup};
    stimTrace(find(stimTrace==5)) = 3;
    stimTrace(find(stimTrace==6)) = 2;
    stimTrace(find(stimTrace==7)) = 1;
    stimTrace(find(stimTrace==8)) = 0;
    
    for iROI = 1:ROInum(currGroup)
        currTrace = currResp(iROI,:);
        pCorr(iROI) = corr(stimTrace',currTrace','type','Spearman');
        
        neg_corr_ind{currGroup} = find(pCorr<0);
    end
    [corr_fly{currGroup},corr_fly_mean{currGroup},corr_fly_error{currGroup}]...
        = mean_cat_full(pCorr',1,flyIDs{currGroup});
    
    BP_corr_fly = [BP_corr_fly corr_fly{currGroup}'];
    labels_corr_fly = [labels_corr_fly (ones(length(corr_fly{currGroup}),1)*currGroup)'];
    
    BP_corr_ROI = [BP_corr_ROI pCorr];
    labels_corr_ROI = [labels_corr_ROI (ones(length(pCorr),1)*currGroup)'];

    box_labels{currGroup} = char(gen_str{currGroup});
end
subplot(2,1,1)
boxplot(BP_corr_ROI,labels_corr_ROI,'Notch','on');
set(gca,'xticklabels',box_labels)
set(gca,'XTickLabelRotation',45)
title('Spearman correlation between stimulus and response over ROI')
ylabel('P corr')

subplot(2,1,2)
boxplot(BP_corr_fly,labels_corr_fly,'Notch','on');
set(gca,'xticklabels',box_labels)
set(gca,'XTickLabelRotation',45)
title('Spearman correlation between stimulus and response over Fly')
ylabel('P corr')
% pause
% [p,tbl,stats] = anova1(BP_corr_fly,labels_corr_fly);
% multcompare(stats)

%% Compact plot for plotting only neg corr ROIs
figure('Color','w')
iColor=1;
for i = 1: numberOfGroups
    % Figure properties
    currFlyIDs = flyIDs{i};
    currFlyIDs = currFlyIDs(neg_corr_ind{i});
    flyNum = length(unique(currFlyIDs));
    genotypeName = sprintf([char(gen_str{i}) ', N: %d ( %d ) with correlation < 0'],flyNum,length(neg_corr_ind{i}));
   
    % Subplot1 all ROIs
    subplot(numberOfGroups,1,i)
    
    % Stimulus conversion
    stimTrace = stimulus{i};
    stimTrace(find(stimTrace==5)) = 3;
    stimTrace(find(stimTrace==6)) = 2;
    stimTrace(find(stimTrace==7)) = 1;
    stimTrace(find(stimTrace==8)) = 0;
    
    curr_resp = responses{i};
    maxVal = max(max(curr_resp));
    negCorrResp = curr_resp(neg_corr_ind{i},:);
    
    plot(negCorrResp','LineWidth',0.5,'Color',[0 0 0 0.1])
    hold on;
    plot(mean(negCorrResp),'LineWidth',3,'DisplayName',genotypeName,...
        'Color',colorss{iColor});
    
    plot((stimTrace/max(stimTrace))*maxVal,'LineWidth',1,'DisplayName','Stimulus','Color','k');
    
    title(genotypeName)
    
    xlabel('Time')
    ylabel('dF/F')
    iColor = iColor+2;
    
end


%% Analysis over flies
f4 = figure('Color','w')
iColor=1;
for i = 1: numberOfGroups
    % Figure properties
    currFlyIDs = flyIDs{i};
    currFlyIDs = currFlyIDs(neg_corr_ind{i});
    flyNum = length(unique(currFlyIDs));
    genotypeName = sprintf([char(gen_str{i}) ', N: %d ( %d ) with correlation < 0'],flyNum,length(neg_corr_ind{i}));
   
    % Subplot1 all ROIs
    subplot(numberOfGroups,1,i)
    
    % Stimulus conversion
    stimTrace = stimulus{i};
    stimTrace(find(stimTrace==5)) = 3;
    stimTrace(find(stimTrace==6)) = 2;
    stimTrace(find(stimTrace==7)) = 1;
    stimTrace(find(stimTrace==8)) = 0;
    
    curr_resp = responses{i};
    negCorrResp = curr_resp(neg_corr_ind{i},:);
    
    [fly_resp,fly_mean,fly_error] = mean_cat_full(negCorrResp,1,currFlyIDs); %m=mean; e=std
    maxVal = max(max(fly_resp));
    
    plot(fly_resp','LineWidth',0.5,'Color',[0 0 0 0.1])
    hold on;
    plot(mean(fly_resp),'LineWidth',3,'DisplayName',genotypeName,...
        'Color',colorss{iColor});
    
    plot((stimTrace/max(stimTrace))*maxVal,'LineWidth',1,'DisplayName','Stimulus','Color','k');
    
    title(genotypeName)
    
    xlabel('Time')
    ylabel('dF/F')
    iColor = iColor+2;
    
    
end

for i = 1: numberOfGroups
    
    % Figure properties
    currFlyIDs = flyIDs{i};
    currFlyIDs = currFlyIDs(neg_corr_ind{i});
    flyNum = length(unique(currFlyIDs));
    genotypeName = sprintf([char(gen_str{i}) ', N: %d ( %d ) with correlation < 0'],flyNum,length(neg_corr_ind{i}));

    curr_resp = responses{i};
    negCorrResp = curr_resp(neg_corr_ind{i},:);
    
    [fly_resp,fly_mean,fly_error] = mean_cat_full(negCorrResp,1,currFlyIDs); %m=mean; e=std
    maxVal = max(max(fly_resp));
    % Analyzing step responses and plateau responses
    stim_epochs= length(unique(stimulus{i}));
    endEpoch = 0;
    for iEpoch = 1:stim_epochs
        clear epoch_step_response_long epoch_plat_response_long
        startEpoch = endEpoch + 1;
        
        endEpoch = startEpoch + options.interpolation_rate*10-1;
        epoch_step_response_long = fly_resp(:,startEpoch:startEpoch+20);
        
        if iEpoch < 6
            epoch_step_response(:,iEpoch) = abs(min(epoch_step_response_long,[],2)-...
            epoch_step_response_long(:,1));
        else
            epoch_step_response(:,iEpoch) = max(epoch_step_response_long,[],2)-...
            epoch_step_response_long(:,1);
        end
        
        epoch_plat_response_long = fly_resp(:,endEpoch-21:endEpoch-1);
        epoch_plat_response(:,iEpoch) = mean(epoch_plat_response_long,2);
    end
    
    mean_step = mean(epoch_step_response);
    err_step = std(epoch_step_response)./sqrt(size(epoch_step_response,1));
    
    
    figure
    
    
    mean_plat = mean(epoch_plat_response);
    err_plat = std(epoch_plat_response)./sqrt(size(epoch_plat_response,1));
    
    % To combine same luminance levels
    combined_plat_resp = [epoch_plat_response(:,1:4) ; fliplr(epoch_plat_response(:,6:9))];
    combined_err = std(combined_plat_resp)./sqrt(size(epoch_plat_response,1));
    combined_err = [combined_err err_plat(5)];
    combined_mean = (mean_plat(1:4) + fliplr(mean_plat(6:9)))/2;
    combined_mean = [combined_mean mean_plat(5)];
    
    luminance_values = [0 0.25 0.5 0.75 1 0.75 0.5 0.25 0];
    color_map =varycolor(2);
    startStim = [1 6];
    endStim = [5 9];
    names = {'1st Part';'2nd Part'};
    e1 = errorbar(luminance_values(1:5),...
            combined_mean,...
            combined_err,'--o');
    
    e1.MarkerSize = 7;
    e1.CapSize = 0;
    e1.MarkerFaceColor = 'k';
    e1.Color = 'k';
    hold on;

    
    
end
%


%% script to read in database and make various categories...

[fname,datetime,frames,zdepth,tottime,stimbouts,locnum,...
    activecells,inverted,stimcode,quality,driver,...
    moving,layer,wavelength,flyID, responsivefly, condition, FlyLayer, ...
    ExperimentType, cond1, cond2, cond3, ProjCurrent]...
    =textread('MASTER_foldersummary_Burak.txt',...
    '%s %s %f %f %f %f %f %s %f %s %f %s %f %s %f %f %f %s %f %s %s %f %s %f',...
    'headerlines',1,'delimiter','\t');


%% Stimulus Codes

% Full Field Flashes
i_fff5s = strcmpi('LocalCircle_5sec_220deg_0degAz_0degEl_Sequential_LumDec_LumInc',(stimcode)); 
i_fff2s = strcmpi('LocalCircle_2sec_220deg_0degAz_0degEl_Sequential_LumDec_LumInc',(stimcode));
i_fff2sONgrayOFF = strcmpi('LocalCircle_2sONgrayOFFgray_120deg_0degAz_0degEl_2Lum',(stimcode)); 
i_fff5sONgrayOFF = strcmpi('LocalCircle_5sONgrayOFFgray_120deg_0degAz_0degEl_2Lum',(stimcode)); 
i_fff_steps_2sONgrayOFF  = strcmpi('LocalCircle_0.1steps_2sONgrayOFFgray_120deg_0degAz_0degEl_2Lum-random',(stimcode)); 

i_FFF_ONOFF_10sBG_5s = strcmpi('FFF_ONOFF_10sBG_5s',(stimcode)); 
i_FFF_ONOFF_4sBG_2s_3ONOFFSteps = strcmpi('FFF_ONOFF_4sBG_2s_3ONOFFSteps',(stimcode)); 


% For 25ms added by Fabiola
i_fffOngrayOFF25ms = strcmpi('LocalCircle_ONgreyOFF_25ms_BG_2s_120deg_0degAz_0degEl_100_Con_0.5Lum', (stimcode));

% Moving bars

i_drifting_edge_20degps_Rand4DIR = strcmpi('DriftingEdge_LumDecLumInc_1period_20degPerSec_90deg_BlankRand_4Dirs', (stimcode));

% FFF contrast changes with a gray background
i_fff2sONgrayOFF4sBG_NonRand = strcmpi('LocalCircle_ONOFF_2s_BG_4s_120deg_0degAz_0degEl_100_Con_0.5Lum_NonRand',(stimcode));
i_fff2sONgrayOFF4sBG_Rand = strcmpi('LocalCircle_ONOFF_2s_BG_4s_120deg_0degAz_0degEl_100_Con_0.5Lum',(stimcode));

% Steps of random luminance
i_fff_05steps_10sONgrayOFF = strcmpi('LocalCircle_0.5steps_10s_randSteps_120deg_0degAz_0degEl_2Lum',(stimcode));
i_fff_nonRand_5lumSteps_10s = strcmpi('nonRand_Inc_4_Dec_4_0.5Steps_10s',(stimcode));

% Impulse flashes
i_fff25msONgrayOFF4sBG = ...
    strcmpi('LocalCircle_ONgreyOFF_25ms_BG_2s_120deg_0degAz_0degEl_100_Con_0.5Lum',(stimcode));
i_milisFlash_1_5sBG_20ms_1cont_0_5_ON_BG_OFF = ...
    strcmpi('milisFlash_1.5sBG_20ms_1cont_0.5_ON_BG_OFF',(stimcode));

i_milisFlash_2sBG_20ms_1cont_0_5_ON_BG_OFF = ...
    strcmpi('milisFlash_2sBG_20ms_1cont_0.5_ON_BG_OFF',(stimcode)); 

i_milisFlash_4sBG_20ms_1cont_0_5_ON_BG_OFF = ...
    strcmpi('milisFlash_4sBG_20ms_1cont_0.5_ON_BG_OFF',(stimcode)); % Current one


% Standing stripes
% i_standingstripes_y_m = strcmpi('StandingStripe_1s_YAxis_5degWide_2degSep_m1.0Con_rand_USEFRUSTUM',(stimcode));

% Drifting stripe with different speeds
i_1Dir_DriftingStripes_2s_BG_4s_7speeds_15to840 = ...
    strcmpi('1Dir_DriftingStripes_2s_BG_4s_7speeds_15-30-90-180-270-540-840',(stimcode));

% Gratings with different speeds
i_Gratings_7speeds_30deg_speedStimTimeAdjusted = ...
    strcmpi('DriftingSquare_16s_8s_4s_BG_5s_6_30deg_tempFreq_0.1-0.2-0.4-1-2-4-8_moving_BlankRand_1Dir',(stimcode));

i_Moving_gratings4D_05_to_27Hz_7diff_4sBG = ...
    strcmpi('4Dir_DriftingSquare_4s_BG_4s_7_30deg_tempFreq_0.5-1-3-6-9-18-27_moving_BlankRand_4Dir',(stimcode));

i_Moving_gratings1D_05_to_27Hz_7diff_4sBG = ...
    strcmpi('1Dir_DriftingSquare_4s_BG_4s_7_30deg_tempFreq_0.5-1-3-6-9-18-27_moving_BlankRand_4Dir',(stimcode));

% Contrast and luminance assessing stimuli 
i_OFF_A_step_B_step = ...
    strcmpi('FullField_OFF_ 2s_OFF_2s_1s_BG_15s_con_m25_lum_0d75to0_NonRand',(stimcode));

i_ON_A_B_5sBG_3sSteps = ...
    strcmpi('FullField_ON_ 2s_ON_2s_1s_BG_15s_con_m25_lum_0d75to0_Rand',(stimcode))

i_ON_A_B_5sBG_4sSteps = ...
    strcmpi('FullField_ON_ 2s_ON_2s_1s_BG_15s_con_m25_lum_0d75to0_Rand_v2',(stimcode))

i_FullField_OFF_1s_OFF_1s = ...
    strcmpi('FullField_OFF_1s_OFF_1s_1s_BG_15s_con_m25_lum_0d75to0_NonRand',(stimcode));
i_FullField_OFF_10s_OFF_10s = ...
    strcmpi('FullField_OFF_10s_OFF_10s_1s_BG_15s_con_m25_lum_0d75to0_NonRand',(stimcode));


%% Genotypes

% PR
i_ninaE_GC6f = strcmpi('ninaE_GC6f',driver);

% L1 genotypes

%c202 x Gc6f on 2nd chromosome
i_L1_c202_Gal4_x_Chr2_UAS_GC6f = strcmpi('L1_c202_Gal4_x_Chr2_UAS_GC6f',driver);

% split x Gc6f on 2nd chromosome
i_L1_R48A08_AD_R66A01_DBD_Gal4_x_2chr_UAS_GC6f = strcmpi('L1_R48A08_AD_R66A01_DBD_Gal4_x_2chr_UAS_GC6f',driver);

% L2 39D12LexA
i_wt_x_39D12LexA_lexAopGCaMP6f = strcmpi('wt_x_39D12LexA_lexAopGCaMP6f',driver);

%DPR-Dipgamma Genotypes
i_Tm9LexAGCaMP6F = strcmpi('Tm9LexAp65GCaMP6F',driver);
i_Tm9LexAGCaMP6F_DIPgammacontrol = strcmpi('Tm9LexAlexAopGCaMP6f_DIPgammaControl',driver);
i_Tm9LexAGCaMP6F_Dfcontrol = strcmpi('Tm9LexAlexAopGCaMP6f_DfControl',driver);
i_Tm9LexAGCaMP6F_Df_DIPgammaexperimental = strcmpi('Tm9LexAlexAopGCaMP6f_Df_DIPgammaExperimental',driver);

%ermRNAi Genotypes
i_Tm9LexAGCaMP6F_9B08Gal4_Control = strcmpi('Tm9LexAlaxAopGCaMP6F_9B08Gal4_Control',driver);
i_Tm9LexAGCaMP6F_9B08Gal4_ermRNAi = strcmpi('Tm9LexAlaxAopGCaMP6F_9B08Gal4_ermRNAi',driver);
i_Tm9LexAlaxAopGCaMP6F_UASermRNAi_Control = strcmpi('Tm9LexAlaxAopGCaMP6F_UASermRNAi_Control',driver);

%Tm9 Imaging L3 UAS Kir
i_Tm9LexAlaxAopGCaMP6F_UASKir2p1_negControl = strcmpi('Tm9LexAlaxAopGCaMP6F_UASKir_negControl',driver);
i_Tm9LexAlaxAopGCaMP6F_Rh1Gal4_UAS_Kir = strcmpi('Tm9LexAlaxAopGCaMP6F_Rh1Gal4_UAS_Kir',driver);
i_Tm9LexAlaxAopGCaMP6F_L3SplitGal4_UAS_Kir = strcmpi('Tm9LexAlaxAopGCaMP6F_L3SplitGal4_UAS_Kir',driver);
i_Tm9LexAlaxAopGCaMP6F_L3MH56Gal4_UAS_Kir = strcmpi('Tm9LexAlaxAopGCaMP6F_L3MH56Gal4_UAS_Kir',driver);

%ermRNAi Marion's Dataset
i_Marion_Dataset_Tm9LexAGCaMP6F_9B08Gal4_Control = strcmpi('Tm9LexA_lexAopGCaMP6f_L3_9B08Gal4contr',driver);
i_Marion_Dataset_Tm9LexAGCaMP6F_9B08Gal4_ermRNAi = strcmpi('Tm9LexA_lexAopGCaMP6f_L3_9B08Gal4_ermRNAi',driver);
i_Marion_Dataset_Tm9LexAlaxAopGCaMP6F_UASermRNAi_Control = strcmpi('Tm9LexA_lexAopGCaMP6f_UASermRNAicontr',driver);


%UAS-GCaMP6f;L2[21Dhh-Gal4] or MH56-Gal4 x w+
i_UASGCaMP6F_L3MH56Gal4 = strcmpi('UASGCaMP6f_L3MH56Gal4',driver);
i_UASGCaMP6F_L221DhhGal4= strcmpi('UASGCaMP6F_L221DhhGal4',driver);
i_UASGCaMP6F_L221DhhGal4_cross_to_w = strcmpi('UASGCaMP6F_L221DhhGal4_cross_to_w',driver);


%L3MH56 and L221Dhh Gal4 together with UAS-Gc6f
i_L3MH56Gal4_L221DhhGal4_UAS_GCaMP6f= strcmpi('L3MH56Gal4_L221DhhGal4_UAS_GCaMP6f',driver);

% LexA
i_lexAopGCaMP6f_x_L2_39D12LexA= strcmpi('lexAopGCaMP6f_x_L2_39D12LexA',driver);


%RNAi
i_RNAi_Ih_L221DhhGal4_UASGCaMP6f = ...
    strcmpi('RNAi_Ih_L221DhhGal4_UASGCaMP6f',driver);
i_RNAi_Ih_MH56Gal4_UASGCaMP6f = ...
    strcmpi('RNAi_Ih_MH56Gal4_UASGCaMP6f',driver);
i_RNAi_Slob_L221DhhGal4_UASGCaMP6f = ...
    strcmpi('RNAi_Slob_L221DhhGal4_UASGCaMP6f',driver);
i_RNAi_cac_L221DhhGal4_UASGCaMP6f = ...
    strcmpi('RNAi_cac_L221DhhGal4_UASGCaMP6f',driver);
i_RNAi_cac_MH56Gal4_UASGCaMP6f = ...
    strcmpi('RNAi_cac_MH56Gal4_UASGCaMP6f',driver);
i_RNAi_Sh_L221DhhGal4_UASGCaMP6f = ...
    strcmpi('RNAi_Sh_L221DhhGal4_UASGCaMP6f',driver);
i_RNAi_Sh_MH56Gal4_UASGCaMP6f = ...
    strcmpi('RNAi_Sh_MH56Gal4_UASGCaMP6f',driver);
i_RNAi_Caalpha1T_MH56Gal4_UASGCaMP6f = ...
    strcmpi('RNAi_Caalpha1T_MH56Gal4_UASGCaMP6f',driver);

%Shal experiments
i_UAS_Shal_L3MH56Gal4_UASGCaMP6f = ...
    strcmpi('UAS_Shal_L3MH56Gal4_UASGCaMP6f',driver);
i_UAS_Shal_L3MH56Gal4_UASGCaMP6f_29deg = ...
    strcmpi('UAS_Shal_L3MH56Gal4_UASGCaMP6f_29deg',driver); % UAS Shal 29 deg
i_UASGCaMP6f_L3MH56Gal4_29deg = ...
    strcmpi('UASGCaMP6f_L3MH56Gal4_29deg',driver); % 29 deg control
i_RNAi_Shal_L221DhhGal4_UASGCaMP6f = ...
    strcmpi('RNAi_Shal_L221DhhGal4_UASGCaMP6f',driver);
i_UAS_DNKv4_L221DhhGal4_UASGCaMP6f = ...
    strcmpi('UAS_DNKv4_L221DhhGal4_UASGCaMP6f',driver);

i_RNAi_ctrl_Shal_2chr_KK_39D12LexA_lexAopGCaMP6f = ...
    strcmpi('RNAi_ctrl_Shal_2chr_KK_39D12LexA_lexAopGCaMP6f',driver);
i_RNAi_exp_Shal_2chr_KK_L221DhhGal4_39D12LexA_lexAopGCaMP6f = ...
    strcmpi('RNAi_exp_Shal_2chr_KK_L221DhhGal4_39D12LexA_lexAopGCaMP6f',driver);

% DIP gamma epsilon Double mutant experiments
i_Tm9LexA_lexAopGCaMP6f_hetero_Dipgamma_epsilon = ...
    strcmpi('Tm9LexA_lexAopGCaMP6f_hetero_Dipgamma_epsilon',driver);
i_Tm9LexA_lexAopGCaMP6f_homo_Dipgamma_epsilon = ...
    strcmpi('Tm9LexA_lexAopGCaMP6f_homo_Dipgamma_epsilon',driver);

% Katja's L2 ort rescue
i_UASort_UASGCaMP6f_L221DhhGal4_ort1_DfBSC809_Helen = ...
    strcmpi('UASort_UASGCaMP6f_L221DhhGal4_ort1_DfBSC809_Helen',driver);
i_L3_ort_rescue_katja = ...
    strcmpi('L3_ort_rescue_katja',driver);

% L2 imaging L3 silencing
i_MH56Gal4_39D12LexA_x_UASshiTS_lexAopGCaMP6f = ...
    strcmpi('MH56Gal4_39D12LexA_x_UASshiTS_lexAopGCaMP6f',driver); %EXP
i_MH56Gal4_39D12LexA_x_lexAopGCaMP6f = ...
    strcmpi('MH56Gal4_39D12LexA_x_lexAopGCaMP6f',driver); %Gal4 ctrl
i_BI_39D12LexA_x_UASshiTS_lexAopGCaMP6f = ...
    strcmpi('BI_39D12LexA_x_UASshiTS_lexAopGCaMP6f',driver); % UAS ShiTS control (also with BI balancer)
i_39D12LexA_x_UASshiTS_lexAopGCaMP6f = ...
    strcmpi('_+_39D12LexA_x_UASshiTS_lexAopGCaMP6f',driver); % UAS ShiTS control (proper control without balancer)

% T4 T5
i_T4_T5_recomb_lexA_lexAopGCaMP6f_Homo = ...
    strcmpi('T4_T5_recomb_lexA_lexAopGCaMP6f_Homo',driver); %T4 T5 LexA,lexAopGC6f recombinant line crossed to itself

% ON pathway neurons

i_Mi9_2432_split = ...
    strcmpi('Mi9_2432_SplitGal4_UAS_GCaMP6f',driver); % Mi9 2432 split Gal4

i_Mi4_316_split = ...
    strcmpi('Mi4_316_SplitGal4_UAS_GCaMP6f',driver); % Mi4 316 split Gal4
%% Condition or toxins
i_No_toxin = strcmpi('No_toxin', condition);

i_Sham = strcmpi('Sham', condition);

i_Agitoxin_200nM = strcmpi('Agitoxin_0.2uM', condition);

i_Phrixotoxin_500nM = strcmpi('Phrixotoxin_500nM', condition);
i_Phrixotoxin_500nM_washed = strcmpi('Phrixotoxin_500nM_washed', condition);
i_Phrixotoxin_1uM = strcmpi('Phrixotoxin_1uM', condition);

i_Dendrotoxin_200nM = strcmpi('Dendrotoxin_200nM', condition);

i_PLTXII_100nM = strcmpi('PLTXII_100nM', condition);

i_Agi_200nM_Phrixo_500nM = strcmpi('Agi_200nM_Phrixo_500nM', condition);

i_Amiloride_1mM = strcmpi('Amiloride_1mM', condition);

i_TTX_1uM = strcmpi('TTX_1uM', condition);
i_TTX_Dendro_1uM_200nM = strcmpi('TTX_Dendro_1uM_200nM', condition);
i_TTX_Dendro_1uM_200nM_wash = strcmpi('TTX_Dendro_1uM_200nM_wash', condition);

i_PTX_100uM = strcmpi('PTX_100uM', condition);
i_PTX_5uM = strcmpi('PTX_5uM', condition);
i_PTX_2_5uM = strcmpi('PTX_2_5uM', condition);

% Temperature controller conditions
i_before_T_shift = strcmpi('before_T_shift', condition);
i_after_T_shift = strcmpi('after_T_shift', condition);

% Katja and marvin datasets
i_katja_dataset = strcmpi('katja_dataset', condition);
i_marvin_dataset = strcmpi('marvin_dataset', condition);

%% Cond1 or Toxin Time Ranges
i_5_10 = strcmpi('5_10' , cond1);
i_11_20 = strcmpi('11_20' , cond1);
i_21_30 = strcmpi('21_30' , cond1);

i_exp_L2_Shal_RNAi = strcmpi('exp_L2_Shal_RNAi' , cond1);
%% Cond2 is continuous with numbers

%% Cond 3 
i_K_toxins = strcmpi('K' , cond3);
i_K_notoxins = strcmpi('K_no' , cond3);

% Impulse FFF conditions
i_old_flash_settings = strcmpi('old_flash_settings', cond3);
i_new_flash_settings = strcmpi('new_flash_settings', cond3);

%% Experiment Types
i_exp_L2_Sham = strcmpi('exp_L2_Sham', ExperimentType);

% Seb paper
%L1 PTX
i_exp_L1_c202_PTX_5_1 = strcmpi('exp_L1_c202_PTX_5_1', ExperimentType);
i_exp_L1_c202_PTX_100_1 = strcmpi('exp_L1_c202_PTX_100_1', ExperimentType);

i_exp_L1_split_ptx_1 = strcmpi('exp_L1_split_ptx_1', ExperimentType);


% Katja paper
i_exp_Katja_paper = strcmpi('katja_paper_dataset', ExperimentType);

%Toxins
i_exp_Agitoxin_200nM = strcmpi('exp_Agitoxin_0.2uM', ExperimentType);
% 2nd experiment batch for impulse responses
i_exp_2_Agitoxin_200nM = strcmpi('exp_2_Agitoxin_0.2uM', ExperimentType); 

i_exp_Phrixotoxin_500nM = strcmpi('exp_Phrixotoxin_500nM', ExperimentType);
i_exp2_Phrixotoxin_500nM = strcmpi('exp2_Phrixotoxin_500nM', ExperimentType);
i_exp3_Phrixotoxin_500nM = strcmpi('exp3_Phrixotoxin_500nM', ExperimentType);

i_exp_Dendrotoxin_200nM = strcmpi('exp_Dendrotoxin_200nM', ExperimentType);

i_exp_PLTXII_100nM = strcmpi('exp_PLTXII_100nM', ExperimentType);

i_exp_Phrixotoxin_1uM = strcmpi('exp_Phrixotoxin_1uM', ExperimentType);

i_exp_Agi_200nM_Phrixo_500nM = strcmpi('exp_Agi_200nM_Phrixo_500nM', ExperimentType);

i_exp_Amiloride_1mM = strcmpi('exp_Amiloride_1mM', ExperimentType);

i_exp_TTX_1uM = strcmpi('exp_TTX_1uM', ExperimentType);

%Tm9
i_exp_Tm9 = strcmpi('exp_Tm9', ExperimentType);

i_exp_Tm9_L3Kir = strcmpi('exp_Tm9_L3Kir', ExperimentType);

i_exp_Tm9_DoubleMutant = strcmpi('exp_Tm9_DoubleMutant', ExperimentType);


%Shal
i_exp_L2_Shal = strcmpi('exp_L2_Shal', ExperimentType);

i_exp_L3_Shal = strcmpi('exp_L3_Shal', ExperimentType);

i_exp_Shal_KK_2_RNAi = strcmpi('exp_Shal_KK_2_RNAi', ExperimentType);

% L2 imaging L3 silencing
i_exp_bath_30min = strcmpi('exp_bath_30min', ExperimentType);
i_exp_bath_50min = strcmpi('exp_bath_50min', ExperimentType);
i_exp_bath_1h = strcmpi('exp_bath_1h', ExperimentType);


i_exp_T_controller = strcmpi('exp_T_controller', ExperimentType);

%Marvin's ttx
i_exp_Marvin_TTX = strcmpi('exp_Marvin_TTX', ExperimentType);

%PTX
i_exp_PTX_5uM_1 = strcmpi('exp_PTX_5uM_1', ExperimentType);
i_exp_L2_L3_PTX = strcmpi('exp_L2_L3_PTX', ExperimentType);

%
i_exp_sebDataset = strcmpi('exp_seb_dataset', ExperimentType);

%% Layers

%Fly layer of interest in format FlyID00LayerNumber (31001) should be
%written in the find part of the analysis script

%% Other Information

i_15bouts = stimbouts>=15;
i_inverted = (inverted == 1);
i_moving = (moving == 1);
i_active = (quality ~= 0);
i_good_q = (quality > 3);
i_great_q = (quality > 5);
i_responsivefly = (responsivefly == 1);  %ms addition
i_30_current = (ProjCurrent == 30);
i_120_current = (ProjCurrent == 120);
i_lob1 = strcmpi('lob1',layer);

i_Toxin_time = cond2;
i_447 = (wavelength == 447);

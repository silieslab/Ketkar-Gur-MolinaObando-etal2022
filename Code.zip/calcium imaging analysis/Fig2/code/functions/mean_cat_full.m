function [grouped_dataset,mean_dataset,error_dataset,unique_categories]=...
    mean_cat_full(dataset,dimension_to_group,all_categories)

% computes mean and sem of a along dimension dim, grouped first by category
% cats
% Modified by BG

% Transpose the dataset if the dimension to group is 2
if dimension_to_group == 2
    dataset=dataset';
end

% Finding the categories that have valid data values
fnan=find(all(~isnan(dataset),2));
dataset=dataset(fnan,:);
valid_categories=all_categories(fnan);

unique_categories=unique(valid_categories);

grouped_dataset=zeros(length(unique_categories),size(dataset,2));
for ii=1:length(unique_categories)
    grouped_dataset(ii,:)=mean(dataset(find(valid_categories==unique_categories(ii)),:),1);
end

mean_dataset=mean(grouped_dataset,1);
error_dataset=std(grouped_dataset,[],1)/sqrt(length(unique_categories));


function mi = calculate_MI_L1_paper(neuronRawData)
% This function calculates mutual information and correlation 
% Used for Sporar et al.

%% For each ROI MI separately
FPS = 10;
% Nearest neighbor estimation parameter K
K = 20; % manual entry
mi = zeros(length(neuronRawData.raw_traces),1);
for iROI=1:length(neuronRawData.raw_traces)
    
    % Getting the raw trace, not using the first 5s
    rawTrace = neuronRawData.raw_traces{iROI};
    rawTrace = rawTrace(5*FPS:end); % getting rid of first 5s (possible noise)
    
    % Bleaching analysis, subtracting a linear fit
    
%     LavSig = log(rawTrace);
%     p = polyfit(1:length(rawTrace),LavSig,1); 
%     bleachTrace = polyval(p,1:length(rawTrace));
%     bleachSubTrace = exp((LavSig - bleachTrace)+mean(LavSig));
%     rawTrace = bleachSubTrace;
    
   
    % dF/F calculation with the mean of the trace
    relativeTrace = rawTrace./mean(rawTrace) - 1; 
     
    % Smoothing with a moving average of 5 to get rid of some fast noise
    relativeTrace = smooth(relativeTrace);
    relativeTrace = relativeTrace';
   
    % Stimuli 
    stimulus = neuronRawData.stim_traces{iROI}(5*FPS:end);
    luminanceTrace = stimulus; 
    
    % MI Brian C. Ross 2014,
    mi(iROI) = discrete_continuous_info_fast(luminanceTrace,relativeTrace,K);


   
end   

%%





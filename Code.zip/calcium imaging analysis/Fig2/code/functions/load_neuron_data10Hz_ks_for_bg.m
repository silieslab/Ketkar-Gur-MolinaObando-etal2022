function out=load_neuron_data10Hz_ks_for_bg(in,locdir,options)

[fname,datetime,frames,zdepth,tottime,stimbouts,locnum,...
    activecells,inverted,stimcode,quality,driver,...
    moving,layer,wavelength,flyID, responsivefly, toxin, FlyLayer, ...
    ExperimentType, AfterToxinTimeRange, TimeAfterToxin, ToxinType]...
    =textread('MASTER_foldersummary_Burak.txt',...
    '%s %s %f %f %f %f %f %s %f %s %f %s %f %s %f %f %f %s %f %s %s %f %s',...
    'headerlines',1,'delimiter','\t');

currd=pwd;
cd(locdir);

count=1;
for ii=1:length(in)
    ii
    qq=in(ii).cell;
    ss=strcmpi(in(ii).name,fname);
    if exist(in(ii).name) * (qq>0)
        x=load(in(ii).name);
        if qq<=size(x.strct.dRatio,1)
            
            if isfield(options,'GroupType')
                % Taking the group as the string until the last number and
                % matching it with group type
                
                for iGroup = 1:length(x.strct.ROIsCategory)
                    currNums = x.strct.ROIsCategory{iGroup}{1};
                    colon = regexp(currNums,':');
                    lowerNum = str2num(currNums(1:colon-1));
                    upperNum = str2num(currNums(colon+1:end));
                    if x.strct.cellNumbers(qq) >= lowerNum && x.strct.cellNumbers(qq) <= upperNum
                        try
                            currROIGroup = x.strct.categoryLabels{iGroup}{1};
                        catch % manually updated ones are not double cell so put this
                            currROIGroup = x.strct.categoryLabels{iGroup};
                        end
                        lastNumIdx = max(regexp(currROIGroup,'\d'));
                        currROIGroupName = currROIGroup(1:lastNumIdx);
                        break
                    end
                end
                if ~strcmp(currROIGroupName,options.GroupType)
                   continue
                end
               
                
            end
            out(count).stimcode=stimcode{ss};
            out(count).quality=quality(ss);
            out(count).driver=driver{ss};
            out(count).layer=layer(ss);
            out(count).wavelength=wavelength(ss);
            out(count).flyID=flyID(ss);
            out(count).name=in(ii).name;
            out(count).cell=in(ii).cell;
            out(count).xml=x.strct.xml;
            out(count).ratio=x.strct.dRatio(qq,:);
            out(count).stim = x.strct.fstimval;
            out(count).raw_stim = x.strct.ch3;
            out(count).avrstimval = x.strct.avrstimval;    
            out(count).frame_nums = x.strct.frame_nums;
            fps=x.strct.xml.framerate;
            %ms: now: # frames / framerate makes timing vector
            out(count).t=[1:length(out(count).ratio)]/fps;
            %ms: new timing vector for interpolation at 10Hz (0.1), starts at ends with 0.5/fps shift 
            out(count).it=[0.5/fps:0.1:(length(out(count).ratio)+0.5)/fps];
            %ms: nearest neighbor interpolation (should maintain discrete values) of .stim (also at 10Hz now)
            %ms: also linearly extrapolates values outside .t
            out(count).istim=interp1(out(count).t,out(count).stim,out(count).it,'nearest','extrap');
            out(count).iavrstim=interp1(out(count).t,out(count).avrstimval,out(count).it,'nearest','extrap'); %ms added
            %ms: same for the ratio, only here we want linear interpolation
            out(count).iratio=interp1(out(count).t,out(count).ratio,out(count).it,'linear','extrap');

                
            % added stimpos and centers, ms
            if(isfield(x.strct,'fstimpos1'))
                out(count).ifstimpos1=interp1(out(count).t,x.strct.fstimpos1,out(count).it,'nearest','extrap');
                out(count).ifstimpos2=interp1(out(count).t,x.strct.fstimpos2,out(count).it,'nearest','extrap');    
            end
            
%             if(isfield(x.strct,'centers'))
%                 out(count).center=x.strct.centers(qq,:);
%             end

%             if(isfield(x.strct,'cell_nums'))
%                 out(count).ref_cell_num = x.strct.cell_nums(qq);
%             end
            
            count=count+1;
        else
            disp([in(ii).name ': cell out of bounds...']);
        end
    else
        disp([in(ii).name ' unfound -- skipping']);
    end
end

cd(currd);
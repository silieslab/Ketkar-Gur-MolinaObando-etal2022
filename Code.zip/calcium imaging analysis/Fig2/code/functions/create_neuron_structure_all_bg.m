function out=create_neuron_structure_all_bg(inds)
% Takes indices you want to analyze as input inds

%Reads the masterfolder and seperates the different categories
[fname,datetime,frames,zdepth,tottime,stimbouts,locnum,...
    activecells,inverted,stimcode,quality,driver,...
    moving,layer,wavelength,flyID, responsivefly, condition, FlyLayer, ...
    ExperimentType, cond1, cond2, cond3, ProjCurrent]...
    =textread('MASTER_foldersummary_Burak.txt',...
    '%s %s %f %f %f %f %f %s %f %s %f %s %f %s %f %f %f %s %f %s %s %f %s %f',...
    'headerlines',1,'delimiter','\t');
out=[];

count=1;
for ii=1:length(inds) %Will iterate for all the indices
    %     ns=str2num(activecells{inds(ii)});
    if exist(fname{inds(ii)}) %If the index has a file name fname
        %         if (length(ns)==0)
        x=load(fname{inds(ii)}); %Load the fname of that index
        ns=[1:size(x.strct.dRatio,1)]; %put dRatio in ns variable for all ROIs
        %         end
        for jj=1:length(ns) %For each ROI in that pDATA
            out(count).name=fname{inds(ii)}; % Put the fname in the output structure
            out(count).cell=ns(jj); %Create a cell for that output index and put each ROIs dRatio
            count=count+1;
        end
    end
end




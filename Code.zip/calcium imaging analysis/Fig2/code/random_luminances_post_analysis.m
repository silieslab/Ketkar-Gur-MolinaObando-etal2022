% Change this variable to your data path
datapath='/Volumes/Backup Plus/PhD_Archive/Data_analysis_ongoing/Matlab_pData';
addpath(genpath((datapath)));
cd(datapath);

%% Load data
l3_data = load('L3_5steps_BurakData.mat');
l3_data = l3_data.data;
l1_data = load('L1_5steps_BurakData.mat');
l1_data = l1_data.data;

% NL - This is not the one used in the paper
[l3_nl_x,l3_nl_m,l3_nl_e] = mean_cat_full(l3_data.nl,1,l3_data.experimentID);
[l1_nl_x,l1_nl_m,l1_nl_e] = mean_cat_full(l1_data.nl,1,l1_data.experimentID);

% GOF

[l3_gof_nl_x,l3_gof_nl_m,l3_gof_nl_e] = mean_cat_full(l3_data.gof_nl,1,l3_data.experimentID);
[l1_gof_nl_x,l1_gof_nl_m,l1_gof_nl_e] = mean_cat_full(l1_data.gof_nl,1,l1_data.experimentID);

[l3_gof_lin_x,l3_gof_lin_m,l3_gof_lin_e] = mean_cat_full(l3_data.gof_lin,1,l3_data.experimentID);
[l1_gof_lin_x,l1_gof_lin_m,l1_gof_lin_e] = mean_cat_full(l1_data.gof_lin,1,l1_data.experimentID);


label_l3 = sprintf('%s %d fly %d ROI','L3',length(l3_nl_x),size(l3_data.responses,1));
label_l1 = sprintf('%s %d fly %d ROI','L1',length(l1_nl_x),size(l1_data.responses,1));

%% Corr Difference calculated here - this is the NL index in the paper
l1_data.corr_diff = l1_data.spearman_c - l1_data.pearson_c;
l3_data.corr_diff = l3_data.spearman_c - l3_data.pearson_c;

[l3_corrD_x,l3_corrD_m,l3_corrD_e] = mean_cat_full(l3_data.corr_diff,1,l3_data.experimentID);
[l1_corrD_x,l1_corrD_m,l1_corrD_e] = mean_cat_full(l1_data.corr_diff,1,l1_data.experimentID);

figure
% boxplot([l1_nl_x; l3_nl_x],[repmat({'L1'},size(l1_nl_x,1),1);repmat({'L3'},size(l3_nl_x,1),1)],'Notch','on','Labels',{label_l1,label_l3})
errorbar(1,l1_corrD_m,l1_corrD_e,'b.','DisplayName',label_l1,'MarkerSize',30,'LineWidth',2)
hold on;
scatter(repmat(1,size(l1_corrD_x,1),1),l1_corrD_x,10,'MarkerFaceColor','b','MarkerFaceAlpha',.3)

errorbar(2,l3_corrD_m,l3_corrD_e,'r.','DisplayName',label_l3,'MarkerSize',30,'LineWidth',2)
scatter(repmat(2,size(l3_corrD_x,1),1),l3_corrD_x,10,'MarkerFaceColor','r','MarkerFaceAlpha',.3)

legend()
xlim([0,3])
% ylim([0 0.2])
[l1_lillie,p] = lillietest(l1_corrD_x);
[l3_lillie,p] = lillietest(l3_corrD_x);
[p,h]= ranksum(l1_corrD_x,l3_corrD_x);

title_str = sprintf('normal dist -lilliefors test- L1:%s L3:%s, Wilcox rank sum p: %.4f', string(not(l1_lillie)),string(not(l3_lillie)),p);
title(title_str)
ylabel("Pearson-Spearman differencee")

% NL
figure
% boxplot([l1_nl_x; l3_nl_x],[repmat({'L1'},size(l1_nl_x,1),1);repmat({'L3'},size(l3_nl_x,1),1)],'Notch','on','Labels',{label_l1,label_l3})
errorbar(1,l1_nl_m,l1_nl_e,'b.','DisplayName',label_l1,'MarkerSize',30,'LineWidth',2)
hold on;
scatter(repmat(1,size(l1_nl_x,1),1),l1_nl_x,10,'MarkerFaceColor','b','MarkerFaceAlpha',.3)

errorbar(2,l3_nl_m,l3_nl_e,'r.','DisplayName',label_l3,'MarkerSize',30,'LineWidth',2)
scatter(repmat(2,size(l3_nl_x,1),1),l3_nl_x,10,'MarkerFaceColor','r','MarkerFaceAlpha',.3)

legend()
xlim([0,3])
% ylim([0 1])
[l1_lillie,p] = lillietest(l1_nl_x);
[l3_lillie,p] = lillietest(l3_nl_x);
[h,p]= ttest2(l1_nl_x,l3_nl_x);

title_str = sprintf('normal dist -lilliefors test- L1:%s L3:%s, ttest p: %.4f', string(not(l1_lillie)),string(not(l3_lillie)),p);
title(title_str)
ylabel("Non linearity")

% GOFs
figure
subplot(121)
% boxplot([l1_nl_x; l3_nl_x],[repmat({'L1'},size(l1_nl_x,1),1);repmat({'L3'},size(l3_nl_x,1),1)],'Notch','on','Labels',{label_l1,label_l3})
errorbar(1,l1_gof_lin_m,l1_gof_lin_e,'b.','DisplayName',label_l1,'MarkerSize',30,'LineWidth',2)
hold on;
scatter(repmat(1,size(l1_gof_lin_x,1),1),l1_gof_lin_x,10,'MarkerFaceColor','b','MarkerFaceAlpha',.3)

errorbar(2,l3_gof_lin_m,l3_gof_lin_e,'r.','DisplayName',label_l3,'MarkerSize',30,'LineWidth',2)
scatter(repmat(2,size(l3_gof_lin_x,1),1),l3_gof_lin_x,10,'MarkerFaceColor','r','MarkerFaceAlpha',.3)

legend()
xlim([0,3])
ylim([0 1])
[l1_lillie,p] = lillietest(l1_gof_lin_x);
[l3_lillie,p] = lillietest(l3_gof_lin_x);
[h,p]= ttest2(l1_gof_lin_x,l3_gof_lin_x);

title_str = sprintf('normal dist -lilliefors test- L1:%s L3:%s, ttest p: %.4f', string(not(l1_lillie)),string(not(l3_lillie)),p);
title(title_str)
ylabel("GOF (R-sq) - Linear")

subplot(122)
% boxplot([l1_nl_x; l3_nl_x],[repmat({'L1'},size(l1_nl_x,1),1);repmat({'L3'},size(l3_nl_x,1),1)],'Notch','on','Labels',{label_l1,label_l3})
errorbar(1,l1_gof_nl_m,l1_gof_nl_e,'b.','DisplayName',label_l1,'MarkerSize',30,'LineWidth',2)
hold on;
scatter(repmat(1,size(l1_gof_nl_x,1),1),l1_gof_nl_x,10,'MarkerFaceColor','b','MarkerFaceAlpha',.3)

errorbar(2,l3_gof_nl_m,l3_gof_nl_e,'r.','DisplayName',label_l3,'MarkerSize',30,'LineWidth',2)
scatter(repmat(2,size(l3_gof_nl_x,1),1),l3_gof_nl_x,10,'MarkerFaceColor','r','MarkerFaceAlpha',.3)

legend()
xlim([0,3])
ylim([0 1])
[l1_lillie,p] = lillietest(l1_gof_nl_x);
[l3_lillie,p] = lillietest(l3_gof_nl_x);
[h,p]= ttest2(l1_gof_nl_x,l3_gof_nl_x);

title_str = sprintf('normal dist -lilliefors test- L1:%s L3:%s, ttest p: %.4f', string(not(l1_lillie)),string(not(l3_lillie)),p);
title(title_str)
ylabel("GOF (R-sq) - 2nd order poly")

%% MI tests

l3_data = load('L3_5steps_BurakData.mat');
l3_data = l3_data.data;
l2_data = load('L2_5steps_BurakData.mat');
l2_data = l2_data.data;
l1_data = load('L1_5steps_BurakData.mat');
l1_data = l1_data.data;

% MI
[l3_mi_x,l3_mi_m,l3_mi_e] = mean_cat_full(l3_data.mi,1,l3_data.experimentID);
[l2_mi_x,l2_mi_m,l2_mi_e] = mean_cat_full(l2_data.mi,1,l2_data.experimentID);
[l1_mi_x,l1_mi_m,l1_mi_e] = mean_cat_full(l1_data.mi,1,l1_data.experimentID);

label_l3 = sprintf('%s %d fly %d ROI','L3',length(l3_mi_x),size(l3_data.responses,1));
label_l2 = sprintf('%s %d fly %d ROI','L2',length(l2_mi_x),size(l2_data.responses,1));
label_l1 = sprintf('%s %d fly %d ROI','L1',length(l1_mi_x),size(l1_data.responses,1));
%% MI Fig

% ylim([0 0.2])
[l1_lillie,p] = lillietest(l1_mi_x);
[l2_lillie,p] = lillietest(l2_mi_x);
[l3_lillie,p] = lillietest(l3_mi_x);

data = [l1_mi_x;l2_mi_x;l3_mi_x];

group = [ones(length(l1_mi_x),1) ...
    ;ones(length(l2_mi_x),1)*2 ;ones(length(l3_mi_x),1)*3];

% All data are normally distributed. Anova
[p,tbl,stats] = anova1(data,group);

c = multcompare(stats,'CType','bonferroni');

%% MI fig
figure
% boxplot([l1_nl_x; l3_nl_x],[repmat({'L1'},size(l1_nl_x,1),1);repmat({'L3'},size(l3_nl_x,1),1)],'Notch','on','Labels',{label_l1,label_l3})
errorbar(1,l1_mi_m,l1_mi_e,'b.','DisplayName',label_l1,'MarkerSize',30,'LineWidth',2)
hold on;
scatter(repmat(1,size(l1_mi_x,1),1),l1_mi_x,10,'MarkerFaceColor','b','MarkerFaceAlpha',.3)

errorbar(2,l2_mi_m,l2_mi_e,'b.','DisplayName',label_l2,'MarkerSize',30,'LineWidth',2)
scatter(repmat(2,size(l2_mi_x,1),1),l2_mi_x,10,'MarkerFaceColor','b','MarkerFaceAlpha',.3)

errorbar(3,l3_mi_m,l3_mi_e,'b.','DisplayName',label_l3,'MarkerSize',30,'LineWidth',2)
scatter(repmat(3,size(l3_mi_x,1),1),l3_mi_x,10,'MarkerFaceColor','b','MarkerFaceAlpha',.3)

legend()
xlim([0,4])
title_str = sprintf('normal dist -lilliefors test- L1:%s L2: %s L3:%s, Anova Bonferonni L1-L2 p: %.5f | L1-L3 p: %.5f | L2-L3 p: %.5f', ...
    string(not(l1_lillie)),string(not(l2_lillie)),string(not(l3_lillie)),c(1,end),c(2,end),c(3,end));
title(title_str)
ylabel("Mutual information")
%% MI violin fig
close all
violinplot([l1_mi_x; l2_mi_x;l3_mi_x],[repmat({'L1'},size(l1_mi_x,1),1);repmat({'L2'},size(l2_mi_x,1),1);repmat({'L3'},size(l3_mi_x,1),1)])

%% baseline responses prepare data
[L1_baseline_x,L1_baseline_m,L1_baseline_e] = mean_cat_full(l1_data.responses-l1_data.responses(:,end),1,l1_data.experimentID);
[L2_baseline_x,L2_baseline_m,L2_baseline_e] = mean_cat_full(l2_data.responses-l2_data.responses(:,end),1,l2_data.experimentID);
[L3_baseline_x,L3_baseline_m,L3_baseline_e] = mean_cat_full(l3_data.responses-l3_data.responses(:,end),1,l3_data.experimentID);



%% figure
luminances = [0,0.25,0.5,0.75,1]; % For plotting

figure(1)
label = sprintf('L1 %d fly %d ROI',length(L1_baseline_x),size(l1_data.responses,1))
% bar(luminances,m,'DisplayName',label )
plot(luminances,L1_baseline_m,'DisplayName',label )
hold on;
errorbar(luminances,L1_baseline_m,L1_baseline_e,'ko')

label = sprintf('L2 %d fly %d ROI',length(L2_baseline_x),size(l2_data.responses,1))
% bar(luminances,m,'DisplayName',label )
plot(luminances,L2_baseline_m,'DisplayName',label )
hold on;
errorbar(luminances,L2_baseline_m,L2_baseline_e,'ko')

label = sprintf('L3 %d fly %d ROI',length(L3_baseline_x),size(l3_data.responses,1))
% bar(luminances,m,'DisplayName',label )
plot(luminances,L3_baseline_m,'DisplayName',label )
hold on;
errorbar(luminances,L3_baseline_m,L3_baseline_e,'ko')




ylim([-0.1,1.1])
xlim([-0.1,1.1])

legend()
grid on
title('Baseline responses')
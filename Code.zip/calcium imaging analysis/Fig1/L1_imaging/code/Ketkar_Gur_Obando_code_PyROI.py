#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 15:09:54 2019

Part of the PyROI that is used in Ketkar, Gur, Obando et al.

@author: burakgur
"""
import numpy as np
import matplotlib.pyplot as plt
import copy
from scipy.stats import linregress
from scipy.stats.stats import pearsonr
from itertools import permutations

class ROI: 
    """A region of interest from an image sequence """
    
    def __init__(self,Mask = None, experiment_info = None,imaging_info = None, uniq_id = None): 
        """ 
        Initialized with a mask and optionally with experiment and imaging
        information
        """
        if (Mask is None):
            raise TypeError('ROI: ROI must be initialized with a mask (numpy array)')
        if (experiment_info is not None):
            self.experiment_info = experiment_info
        if (imaging_info is not None):
            self.imaging_info = imaging_info
            
        if (uniq_id is None):
            self.uniq_id = id(self) # Generate a unique ID everytime it is not given
        else:
            self.uniq_id = uniq_id # Useful during transfer

        self.mask = Mask
        
        
    def __str__(self):
        return '<ROI:{_id}>'.format(_id = self.uniq_id)
    
    def __repr__(self):
        return '<ROI:{_id}>'.format(_id = self.uniq_id)

    def plotDf(self, line_w = 1,color=plt.cm.Dark2(0)):
        a = plt.axes()
        a.plot(self.df_trace, lw=line_w, alpha=.8,color=color)
       
        try:
            stim_vals = self.stim_info['processed']['epoch_trace_frames']
            # Make normalized values of stimulus values for plotting
            stim_vals /= stim_vals.max()
            stim_vals *= self.df_trace.max()
            
            a.plot(stim_vals,'--', lw=1, alpha=.6,color='k')
            plt.show()
        except KeyError:
            print('No raw stimulus information found')
        return a

def data_to_list(rois, data_name_list):
    """ Generates a dictionary with desired variables from ROIs.

    Parameters
    ==========
    rois : list
        A list of ROI instances.
        
    data_name_list: list
        A list of strings with desired variable names. The variables should be 
        written as defined in the ROI class. 
        
    Returns
    =======
    
    roi_data_dict : dictionary 
        A dictionary with keys as desired data variable names and values as
        list of data.
    """   
    class my_dictionary(dict):  
  
        # __init__ function  
        def __init__(self):  
            self = dict()  
              
        # Function to add key:value  
        def add(self, key, value):  
            self[key] = value  
    
    roi_data_dict = my_dictionary()
    
    # Generate an empty dictionary
    for key in data_name_list:
        roi_data_dict.add(key, [])
    
    # Loop through ROIs and get the desired data            
    for iROI, roi in enumerate(rois):
        for key, value in roi_data_dict.items(): 
            if key in roi.__dict__.keys():
                value.append(roi.__dict__[key])
            else:
                value.append(np.nan)
    return roi_data_dict
    
def interpolate_signal(signal, sampling_rate, int_rate=10,int_time = None):
    """
    """

    timeV = np.linspace(1/sampling_rate,(len(signal)+1)/sampling_rate,num = len(signal)) 
    if int_time == None:
        timeVI = np.linspace(1/float(int_rate), (len(signal)+1)/sampling_rate, num = int(round((len(signal)/sampling_rate)*int_rate)))
    else:
        timeVI = np.linspace(1/float(int_rate), int_time, num = int(round(int_time*int_rate)))
                         
    return np.interp(timeVI, timeV, signal)

def threshold_ROIs(rois, threshold_dict):
    """ Thresholds given ROIs and returns the ones passing the threshold.

    Parameters
    ==========
    rois : list
        A list of ROI instances.
        
    threshold_dict: dict
        A dictionary with desired ROI property names that will be 
        thresholded as keys and the corresponding threshold values as values. 
    
    Returns
    =======
    
    thresholded_rois : list 
        A list containing instances of ROI which pass the thresholding step.
    """
    # If there is no threshold
    if threshold_dict is None:
        print('No threshold used.')
        return rois
    vars_to_threshold = threshold_dict.keys()
    
    roi_data_dict = data_to_list(rois, vars_to_threshold)
    
    pass_bool = np.ones((1,len(rois)))
    
    for key, value in threshold_dict.items():
        
        if type(value) == tuple:
            if value[0] == 'b':
                pass_bool = \
                    pass_bool * (np.array(roi_data_dict[key]).flatten() > value[1])
                
            elif value[0] == 's':
                pass_bool = \
                    pass_bool * (np.array(roi_data_dict[key]).flatten() < value[1])
            else:
                raise TypeError("Tuple first value not understood: should be 'b' for bigger than or 's' for smaller than")
                
        else:
            pass_bool = pass_bool * (np.array(roi_data_dict[key]).flatten() > value)
    
    pass_indices = np.where(pass_bool)[1]
    
    thresholded_rois = []
    for idx in pass_indices:
        thresholded_rois.append(rois[idx])
    
    return thresholded_rois

def calculateReliability(rois):
    """ Calculates the correlation between single trials and assigns as reliability for each ROI """
    
    for roi in rois:
        # Compute the lengths
        stim_info = roi.stim_info
        randomization_condition = stim_info['meta']['randomization_condition']
        stim_coords = stim_info['processed']['trial_coordinates']

        roi.reliabilities = []
        # Initialize the randomization related variables
        if (randomization_condition == 1) or (randomization_condition == 3):
            baseline_epoch = 'epoch_1'
            resp_start_idx = 1
            resp_end_idx = 2
            base_start_idx = 0
            base_end_idx = 3

            base_dur = stim_info['meta']['epoch_infos'][baseline_epoch]['total_dur_sec']
            base_len = int(np.floor(base_dur*roi.imaging_info['frame_rate']))
        else:
            baseline_epoch = None
            resp_start_idx = 0
            resp_end_idx = 1
            base_start_idx = 0
            base_end_idx = 1
            base_len = 0
        
        for epoch , epoch_coords in stim_coords.iteritems():
            if epoch == baseline_epoch: # Skip the baseline epoch
                continue
            epoch_dur = stim_info['meta']['epoch_infos'][epoch]['total_dur_sec']

            resp_len = int(np.floor(epoch_dur*rois[0].imaging_info['frame_rate']))
            trial_len = base_len + resp_len + base_len
            
            
            trial_num = len(epoch_coords)
            resp_mat = np.zeros([resp_len,trial_num])
            for iTrial in range(trial_num):
                trial_coords = epoch_coords[iTrial]
                resp_start = trial_coords[resp_start_idx]
                resp_mat[:,iTrial] = roi.df_trace[resp_start:resp_start+resp_len]
            
            perm = permutations(range(trial_num), 2) 
            coeff =[]
            for iPerm, pair in enumerate(perm):
                curr_coeff, pval = pearsonr(resp_mat[:,pair[0]],
                                            resp_mat[:,pair[1]])
                coeff.append(curr_coeff)
                
            roi.reliabilities.append(np.array(coeff).mean())
        roi.reliability = np.max(roi.reliabilities)
    return rois
    
def analyzeLuminanceEdges_L1_ONOFF(rois,int_rate = 10):
        
    for roi in rois:
        stim_info = roi.stim_info
        epoch_infos = stim_info['meta']['epoch_infos']
        randomization_c = stim_info['meta']['randomization_condition']

        if (randomization_c == 1) or (randomization_c == 3):
            baseline_epoch = 'epoch_1'
            used_epochs = epoch_infos.keys()
            used_epochs.remove(baseline_epoch)
            base_dur = epoch_infos[baseline_epoch]['total_dur_sec']
        else:
            baseline_epoch = None

        # Initialize ROI variables
        roi.int_rate = int_rate
        roi.epoch_luminances = {}
        roi.edge_step_responses = {}
        roi.edge_absolute_responses = {}
        roi.int_whole_trace = {}
        roi.int_resp_trace = {}

        interpolated_len = len(interpolate_signal(roi.resp_traces[used_epochs[0]],roi.imaging_info['frame_rate'],int_rate,int_time=int(round(len(roi.resp_traces[used_epochs[0]])/roi.imaging_info['frame_rate'])))) 
        int_resp_traces = np.zeros((len(used_epochs),interpolated_len))

        for idx, epoch in enumerate(used_epochs):
            roi.epoch_luminances[epoch] = epoch_infos[epoch]['edge_lum']

            # Find edge responses
            pre_frames = int(epoch_infos[epoch]['pre_dur_sec'] * roi.imaging_info['frame_rate'])
            pre_lum_mean = roi.resp_traces[epoch][pre_frames-pre_frames/2:pre_frames].mean() # Half of pre-lum dur 500ms
            edge_resp = roi.resp_traces[epoch][pre_frames:].min() # L1 responds negatively

            roi.edge_absolute_responses[epoch] = edge_resp
            roi.edge_step_responses[epoch] = edge_resp - pre_lum_mean

            # Interpolate traces
            roi.int_resp_trace[epoch] = interpolate_signal(roi.resp_traces[epoch],roi.imaging_info['frame_rate'],int_rate=int_rate,int_time=epoch_infos[epoch]['total_dur_sec']) 
            roi.int_whole_trace[epoch] = interpolate_signal(roi.whole_traces[epoch],roi.imaging_info['frame_rate'],int_rate,int_time=int(round(len(roi.whole_traces[epoch])/roi.imaging_info['frame_rate']))) 

            int_resp_traces[idx, :] = roi.int_resp_trace[epoch]
        
        roi.edge_resp_traces_interpolated = int_resp_traces
        fp = roi.imaging_info['frame_rate']
        fp = np.tile(fp,len(used_epochs))

        aligned_traces = np.array(map(lambda trace,fp : np.roll(trace,len(trace)/2 - \
                                            int(np.argmin(trace[10:])+10)),
                     roi.edge_resp_traces_interpolated.copy(),fp))

        roi.max_aligned_traces = aligned_traces.copy()
        roi.concatenated_lum_traces = np.concatenate(aligned_traces)
        lums = [epoch_infos[epoch]['edge_lum'] for epoch in used_epochs]
        X =np.log10(np.array([ 16293.79680931,  31622.8436683 ,  62280.93738627, 123597.12482221,
       184913.31225815, 246229.49969409])) # Real luminance values
        Y = np.abs(roi.edge_step_responses.values())/np.max(np.abs(roi.edge_step_responses.values())) # L1 negative responses require absolute to quantify their amplitude
        X = X[np.argsort(lums)]
        roi.slope = linregress(X, np.transpose(Y))[0]

        # Sorted values
        luminances = roi.epoch_luminances.values()
        roi.sorted_luminances = np.sort(luminances)
        resps = np.array(roi.edge_step_responses.values())
        roi.sorted_edge_step_responses = resps[np.argsort(luminances)]

        resps_abs = np.array(roi.edge_absolute_responses.values())
        roi.sorted_edge_absolute_responses = resps_abs[np.argsort(luminances)]

        
        roi.max_resp = np.min(resps)
        
    return rois
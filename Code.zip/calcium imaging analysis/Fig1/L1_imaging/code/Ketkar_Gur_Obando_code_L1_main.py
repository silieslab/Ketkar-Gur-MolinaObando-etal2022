#%% Required packages

import cPickle
import pandas as pd
import numpy as np
import warnings
import matplotlib
import matplotlib.pyplot as plt
import os
from scipy.stats import linregress
from sklearn import preprocessing
from scipy import stats

# Following are our own code
import Ketkar_Gur_Obando_code_PyROI as PyROI
import Ketkar_Gur_Obando_code_pac as pac

#%% Set target directories
# Change them with your data directories
initialDirectory = '/Volumes/Backup Plus/PhD_Archive/Data_analysis_ongoing/Python_data'
data_dir = os.path.join(initialDirectory, 'analyzed_data','210706_L1_ONOFFpaper') # This should contain .pickle files
datasets_to_load = os.listdir(data_dir) 

results_save_dir = os.path.join(initialDirectory,'results/210715_L1_ONOFF_paper') # Save plots here


# %% Load datasets and desired variables
                    
properties = ['depth','slope']
combined_df = pd.DataFrame(columns=properties)
all_rois = []
all_traces=[]
tunings = []

for idataset, dataset in enumerate(datasets_to_load):
    if not(dataset.split('.')[-1] =='pickle'):
        warnings.warn('Skipping non pickle file: {f}\n'.format(f=dataset))
        continue
    load_path = os.path.join(data_dir, dataset)
    load_path = open(load_path, 'rb')
    workspace = cPickle.load(load_path)

    curr_rois = workspace['final_rois']
    stim_name = curr_rois[0].stim_info['meta']['stim_name']
    if (not('1DONedges' in stim_name)):
        continue
    
    curr_rois = PyROI.analyzeLuminanceEdges_L1_ONOFF(curr_rois,int_rate = 10)
    curr_rois = PyROI.calculateReliability(curr_rois)
    geno = curr_rois[0].experiment_info['Genotype'][:3]
    # L1 rel t: 0.5
    curr_rois = PyROI.threshold_ROIs(curr_rois, {'reliability':0.5})
    if len(curr_rois) <= 1:
        warnings.warn('{d} contains 1 or no ROIs, skipping'.format(d=dataset))
        continue
    all_rois.append(curr_rois)
    
    curr_tuning = np.squeeze\
                   (list(map(lambda roi: roi.sorted_edge_step_responses,curr_rois)))
    tunings.append(curr_tuning)
        
    roi_traces = np.zeros((len(curr_rois),len(curr_rois[0].epoch_luminances),
                           49))
    all_traces.append(np.array\
                      (map(lambda roi : roi.max_aligned_traces[:,:49],
                                   curr_rois)))
    # print(all_traces[0].shape)
    depths = list(map(lambda roi : roi.imaging_info['depth'], curr_rois))
    
    df_c = {}

    data_to_extract = ['reliability','slope','category']
    roi_data = PyROI.data_to_list(curr_rois, data_to_extract)

    df_c['slope'] = roi_data['slope']
    df_c['category'] = roi_data['category']
    df_c['reliability'] = roi_data['reliability']
    df_c['flyID'] = np.tile(curr_rois[0].experiment_info['FlyID'],len(curr_rois))
    df_c['Geno'] = np.tile(geno,len(curr_rois))
    df_c['uniq_id'] = np.array(map(lambda roi : roi.uniq_id, curr_rois)) 
    df = pd.DataFrame.from_dict(df_c) 
    rois_df = pd.DataFrame.from_dict(df)
    combined_df = combined_df.append(rois_df, ignore_index=True, sort=False)
    print(curr_rois[0].experiment_info['Genotype'])
    print(curr_rois[0].stim_info['meta']['stim_name'])
    print('{ds} successfully loaded\n'.format(ds=dataset))

# Encode fly ID names into numbers
le = preprocessing.LabelEncoder()
le.fit(combined_df['flyID'])
combined_df['flyIDNum'] = le.transform(combined_df['flyID'])

all_rois=np.concatenate(all_rois)
all_traces = np.concatenate(all_traces)
tunings = np.concatenate(tunings)

#%% Select color
_, colors = pac.run_matplotlib_params()

c_dict = {k:colors[k] for k in colors if k in combined_df['Geno'].unique()}

# %% Luminance values
# Values from the stimulation paradigm
measurements_f = '/Users/burakgur/Documents/GitHub/python_lab/2p_calcium_imaging/210716_Ultima_Luminances.xlsx'
measurement_df = pd.read_excel(measurements_f,header=0)
res = linregress(measurement_df['file_lum'], measurement_df['measured'])

diff_luminances = all_rois[0].sorted_luminances
candelas = res.intercept + res.slope*diff_luminances
luminances_photon = pac.convert_cd_to_photons(cdVal=candelas,wavelength=475)
        
#%%  Summary figure
plt.close('all')

for idx, geno in enumerate(np.unique(combined_df['Geno'])):
    geno_color = c_dict[geno]
    # neuron_save_dir = os.path.join(results_save_dir,geno,'luminance_edges')
    neuron_save_dir = os.path.join(results_save_dir)
    if not os.path.exists(neuron_save_dir):
        os.mkdir(neuron_save_dir)
    
    curr_neuron_mask = (combined_df['Geno']==geno)
            
    curr_df = combined_df[curr_neuron_mask]
    fig = plt.figure(figsize=(8, 4))
    grid = plt.GridSpec(1, 2, wspace=0.3, hspace=0.3)
    
    ax1=plt.subplot(grid[0,0])
    ax2=plt.subplot(grid[0,1])

    diff_luminances = luminances_photon
    curr_stim_type ='OFF'
        
     
    cmap = matplotlib.cm.get_cmap('inferno')
    norm = matplotlib.colors.Normalize(vmin=0, 
                                       vmax=np.max(diff_luminances))
    
    sensitivities = tunings[curr_neuron_mask]
    properties = ['Luminance', 'Response']
    senst_df = pd.DataFrame(columns=properties)
    colors_lum = []
    for idx_lum, luminance in enumerate(diff_luminances):
        curr_color = cmap(norm(luminance))
        colors_lum.append(curr_color)
        curr_traces = all_traces[curr_neuron_mask,idx_lum,:]
        
        a=pac.compute_over_samples_groups(data = curr_traces, 
                                group_ids= np.array(combined_df[curr_neuron_mask]['flyIDNum']), 
                                error ='SEM',
                                experiment_ids = np.array(combined_df[curr_neuron_mask]['Geno']))

        label = '{g} n: {f}({ROI})'.format(g=geno,
                                           f=len(a['experiment_ids'][geno]['over_samples_means']),
                                           ROI=len(a['experiment_ids'][geno]['all_samples']))
        
        
        mean_r = a['experiment_ids'][geno]['over_groups_mean'][:]
        err = a['experiment_ids'][geno]['over_groups_error'][:]
        
        ub = mean_r + err
        lb = mean_r - err
        x = np.linspace(0,len(mean_r),len(mean_r))
        ax1.plot(x,mean_r,'-',lw=2,color=cmap(norm(luminance)),alpha=.7,
                 label=luminance)
        ax1.fill_between(x, ub, lb,color=cmap(norm(luminance)), alpha=.3)
        ax1.legend()
        
        curr_sensitivities=sensitivities[:,idx_lum]
        curr_luminances = np.ones(curr_sensitivities.shape) * luminance
        df = pd.DataFrame.from_dict({'Luminance':curr_luminances,
                                     'Response':curr_sensitivities}) 
        rois_df = pd.DataFrame.from_dict(df)
        senst_df = senst_df.append(rois_df, ignore_index=True, sort=False)
    ax1.set_ylabel('$\Delta F/F$')
    ax1.set_title('Aligned mean responses {l}'.format(l=label) )   
    
    # AX2
    tuning_curves = np.abs(tunings[curr_neuron_mask])
    
    a=pac.compute_over_samples_groups(data = tuning_curves, 
                                group_ids= np.array(combined_df[curr_neuron_mask]['flyIDNum']), 
                                error ='SEM',
                                experiment_ids = np.array(combined_df[curr_neuron_mask]['Geno']))

    label = '{g} n: {f}({ROI})'.format(g=geno,
                                       f=len(a['experiment_ids'][geno]['over_samples_means']),
                                       ROI=len(a['experiment_ids'][geno]['all_samples']))
    all_mean_data = a['experiment_ids'][geno]['over_groups_mean']
    all_yerr = a['experiment_ids'][geno]['over_groups_error']
    ax2.errorbar(diff_luminances,all_mean_data,all_yerr,
                 fmt='-s',alpha=1,color=geno_color,label=label)
    ax2.set_xscale('log')
    ax2.set_xlim((10**4,10**6))
    ax2.set_ylim((0,ax2.get_ylim()[1]))
    ax2.set_title('Step responses  ') 
    ax2.set_xlabel('Edge luminance (photons perS perR)')
    
    
   
    
    # Saving figure
    save_name = '_Edge_summary_100p_{st}_{geno}'.format(
                                                   st=curr_stim_type,
                                                   geno=geno)
    os.chdir(neuron_save_dir)
    plt.savefig('%s.pdf' % save_name, bbox_inches='tight',dpi=300)
    
    
    
#%% Slope

curr_neuron_mask = (combined_df['Geno']=="L1_")
a=pac.compute_over_samples_groups(data = combined_df['slope'], 
                                group_ids= np.array(combined_df['flyIDNum']), 
                                error ='SEM',
                                experiment_ids = np.array(combined_df['Geno']))

all_mean_data = a['experiment_ids'][geno]['over_groups_mean']
all_yerr = a['experiment_ids'][geno]['over_groups_error']
curr_data = a['experiment_ids'][geno]
error = curr_data['over_groups_error']

fig = plt.figure(figsize=(4, 4))
ax = plt.gca()
pac.bar_bg(curr_data['over_samples_means'], 1, color=c_dict[geno],yerr=error,ax=ax)
ax.set_xlim((0,2))




clear all;
close all;
clc;

% Change this variable to your pData path
pdatapath='/Volumes/Backup Plus/PhD_Archive/Data_analysis_ongoing/Matlab_pData';
addpath(genpath((pdatapath)));
cd(pdatapath);

database_select_samples_bg;
stim_time = 3
gen_str = 'L1'; % Name doesn't matter just for plotting
options.GroupType = 'M1' % 
options = []  % If not L1 use this here
%% Processing Data 
% L1
% f_Tm9LexA = find(i_OFF_A_step_B_step.*i_L1_c202_Gal4_x_Chr2_UAS_GC6f.*i_No_toxin.*~i_moving);




% create structures by neuron
fTm9LexA = create_neuron_structure_all_bg(f_Tm9LexA);

% load all the data!
xTm9LexA = load_neuron_data10Hz_ks_for_bg(fTm9LexA,pdatapath,options);

% This function groups the different interesting epoch combinations in a
% Matrix, stored in combination_storage
mTm9LexA = aggregate_off_off_steps_L1Paper(xTm9LexA);
%% Correlation of Cells

%These are the measured luminance and contrast values for the stimulus

a_luminances = [0.107142857 0.214285714 0.321428571 0.428571428 0.535714284 0.642857141 0.749999998];%[0.435666667 0.377 0.309333333 0.251666667 0.184 0.126333333 ];
a_luminances = flip(a_luminances)
b_luminances = [0.080357143 0.160714286 0.241071429 0.321428573 0.401785716 0.482142859 0.562500002];%[0.329 0.279666667 0.230666667 0.184 0.135666667 0.096666667 ];
b_luminances = flip(b_luminances)

a_contrasts = (a_luminances-1)/1;
b_contrasts = (b_luminances-a_luminances)./a_luminances;
% b_contrasts = (b_luminances-a_luminances)./1;

a_start = 40;
a_end = (a_start+stim_time*10);
b_start=a_end
b_end = (b_start+stim_time*10);


corr_t = 0;

numROIs = size(mTm9LexA.responses,1);
num_epochs = size(mTm9LexA.responses,2);
responses = mTm9LexA.responses;

negative_correlated = zeros(numROIs,1);
positive_correlated = zeros(numROIs,1);

roi_corr = zeros(numROIs,1);
% Check which cells are positively or negatively correlated
for iROI=1:numROIs
    
    resp = max(squeeze(responses(iROI,:,a_start:a_end)),[],2);
    
   
%     plot(squeeze(responses(iROI,:,:))','LineWidth',3)
%     w =waitforbuttonpress;
    
    roi_corr(iROI) = corr(resp,a_contrasts');
    
end

neg_corr_resp = responses(roi_corr<corr_t, :,:);

baseline_resp_a = mean(responses(roi_corr<corr_t, :,a_end-5:a_end),3);
baseline_resp_b = mean(responses(roi_corr<corr_t, :,b_end-5:b_end),3);


step_resp_a = max(responses(roi_corr<corr_t, :,a_start:a_end),[],3) - ...
    mean(responses(roi_corr<corr_t, :,20:40),3);
step_resp_b = max(responses(roi_corr<corr_t, :,b_start:b_end),[],3)- ...
    mean(responses(roi_corr<corr_t, :,20:40),3);

step_resp_a_to_b = max(responses(roi_corr<corr_t, :,b_start:b_end),[],3) - ...
    mean(responses(roi_corr<corr_t, :,a_end-5:a_end),3);

%% Save data
data.a_luminances = a_luminances;
data.b_luminances = b_luminances;
data.a_contrasts = a_contrasts;
data.b_contrasts = b_contrasts;

data.baseline_resp_a = baseline_resp_a;
data.baseline_resp_b = baseline_resp_b;

data.step_resp_a = step_resp_a;
data.step_resp_b = step_resp_b;
data.step_resp_a_to_b = step_resp_a_to_b;

data.responses = neg_corr_resp;
data.experimentID = mTm9LexA.flyID(roi_corr<corr_t);
data.genotype = 'L3'
save('L1_AB.mat','data')


 %%
close all
figure(1)
cmap = copper(num_epochs);
cmap = flip(cmap)
for iEpoch = 1:num_epochs
    curr_traces = squeeze(neg_corr_resp(:,iEpoch,:));
    [x,m,e] = mean_cat_full(curr_traces,1,mTm9LexA.flyID(roi_corr<corr_t));
    
    plot(m','DisplayName',string(a_luminances(iEpoch)),'Color',cmap(iEpoch,:),...
        'LineWidth',3)
    legend()
    hold on;
   
    lum_trace = zeros(length(m),1);
    lum_trace(1:a_start) = 1;
    lum_trace(b_end:end) = 1;
    lum_trace(a_start:a_end) = a_luminances(iEpoch);
    lum_trace(b_start:b_end) = b_luminances(iEpoch);
    plot(lum_trace,'Color',cmap(iEpoch,:),...
        'LineWidth',3)
    
end
title(sprintf('%s %d fly(%d ROI)',gen_str, size(x,1),size(neg_corr_resp,1)))

%%
figure(2)
[aa,m,e] = mean_cat_full(step_resp_a,1,mTm9LexA.flyID(roi_corr<corr_t));
x=a_luminances;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
ax=axes;
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'r.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [1 0 0 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','r');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ylim([0,ax.YLim(2)])
xlim([0,1])


[aa,m,e] = mean_cat_full(step_resp_b,1,mTm9LexA.flyID(roi_corr<corr_t));
x=b_luminances;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'b.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [0 0 1 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','b');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([0,1])

% legend()
% grid on
title('Step response vs luminance')
xlabel('Luminance')
ylabel('Response')

figure(3)
[aa,m,e] = mean_cat_full(step_resp_a,1,mTm9LexA.flyID(roi_corr<corr_t));
x=a_contrasts;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'r.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [1 0 0 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','r');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([-1,0])

% grid on
title('Step response vs contrast')

[aa,m,e] = mean_cat_full(step_resp_b,1,mTm9LexA.flyID(roi_corr<corr_t));
x=b_contrasts;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'b.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [0 0 1 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','b');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([-1,0])

% grid on
title('Step response vs contrast')
xlabel('Contrast')
ylabel('Response')

%%
figure(4)
[aa,m,e] = mean_cat_full(baseline_resp_a,1,mTm9LexA.flyID(roi_corr<corr_t));

x=a_luminances;
y=m;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
ax=axes;
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'r.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [1 0 0 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','r');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([0,1])

[aa,m,e] = mean_cat_full(baseline_resp_b,1,mTm9LexA.flyID(roi_corr<corr_t));

x=b_luminances;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'b.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [0 0 1 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','b');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([0,1])

% legend()
% grid on
title('Baseline vs luminance')
xlabel('Luminance')
ylabel('Response')

figure(5)
[aa,m,e] = mean_cat_full(baseline_resp_a,1,mTm9LexA.flyID(roi_corr<corr_t));

x=a_contrasts;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'r.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [1 0 0 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','r');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([-1,0])


[aa,m,e] = mean_cat_full(baseline_resp_b,1,mTm9LexA.flyID(roi_corr<corr_t));

x=b_contrasts;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'b.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [0 0 1 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','b');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([-1,0])


% legend()
% grid on
title('Baseline vs contrast')
xlabel('Contrast')
ylabel('Response')

%%
figure(6)

[aa,m,e] = mean_cat_full(step_resp_a,1,mTm9LexA.flyID(roi_corr<corr_t));
x=a_contrasts;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'r.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [1 0 0 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','r');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([-1,0])

% grid on
title('Step response vs contrast')

[aa,m,e] = mean_cat_full(step_resp_a_to_b,1,mTm9LexA.flyID(roi_corr<corr_t));
x=b_contrasts;
y=m;
alpha = 1:length(x);
alpha = alpha/length(alpha);
hold on;
for i = 1:length(x)
  e1 = errorbar(x(i),y(i),e(i),'b.');
  e1.MarkerSize = 7;
  e1.LineWidth = 1
  e1.CapSize = 0;
  e1.Color = [0 0 1 alpha(i)];
  s = scatter(x(i),y(i),90,'filled','b');
  s.MarkerFaceAlpha = alpha(i);  %%marking every maker with different alpha value
end
hp = plot(x,y,'--','Color',[0 0 0 0.5],'LineWidth',2)
ax=gca;
ylim([0,ax.YLim(2)])
xlim([-1,0])

% grid on
title('Step response A to B vs contrast')
xlabel('Contrast')
ylabel('Response')



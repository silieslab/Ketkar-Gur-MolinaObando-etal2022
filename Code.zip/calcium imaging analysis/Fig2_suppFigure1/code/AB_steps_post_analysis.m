%% Load data
% Change this variable to your data path
clear all
close all
datapath='/Volumes/Backup Plus/PhD_Archive/Data_analysis_ongoing/Matlab_pData';
addpath(genpath((datapath)));
cd(datapath);
%%
l1_data = load('L1_AB.mat');
l1_data = l1_data.data;



%% Do Anova for B steps

[l1_step_a,~,~] = mean_cat_full(l1_data.step_resp_a,1,l1_data.experimentID);



[l1_step_b,~,~] = mean_cat_full(l1_data.step_resp_b,1,l1_data.experimentID);


label_l1 = sprintf('%s %d fly %d ROI','L1',length(l1_step_b),size(l1_data.responses,1))

%% L1 B steps
% Anova
[p,tbl,stats] = anova1(l1_step_b);

c = multcompare(stats,'CType','bonferroni');








function out = aggregate_off_off_steps_L1Paper(in)
% This function aggregates non_random step epochs together as one epoch
% 
% 0 : 100% OFF
% 1 : 50% OFF
% 2 : GREY
% 3 : 50% ON
% 4 : 100% ON

%figure out epochlength
epochlengths = zeros(1,length(in));

for ii=1:length(in)
    s = in(ii).istim;
    
    % Find beginning indices
    ds = diff(s);
    b_inds = find(ds)+1;
    duration = zeros(1,length(b_inds));
    
    % Calculate each epochduration for this ROI
    for kk =1:length(b_inds)-1
        duration(kk) = b_inds(kk+1)-b_inds(kk);
    end
    
    % Don't take the mean, because sometimes the same epoch is displayed
    % twice, so the epochlength seems to be double. Mode takes 'most
    % common' value
    
    % We need to get rid of the BG durations which are 30s 300
    epochlengths(ii) = mode(duration(duration<250));
end

epochlength = round(mean(epochlengths));

responses = zeros(length(in),length(unique(s))-1,epochlength+80);

%% For each ROI
goodROI = 1;

for iROI=1:length(in)
    
    % df/f
    iratio = in(iROI).iratio;
  
    % Find ending indices
    s = in(iROI).istim;
    
    d_iratio = (iratio./mean(iratio(s==0))) -1;
    

    if (max(d_iratio(500:end)) < 0.3)
%         plot(d_iratio)
%         title(sprintf('max: %.1f',max(d_iratio(100:end))));
%         pause
%         close
        continue
    end
    
    ds = diff(s);
    inds = find(~(ds==0))+1; % 
    inds = inds(2:end-1); % clipping off the first and the last epoch
    
    epochs = s(inds);
    
    if max(epochs) < 7
        continue
    end
    
    roi_resps = zeros(length(unique(s))-1,epochlength+80);
    for jj=1:max(epochs) % number of epochs
        
        I = find(epochs==jj); %ms: take all the epochs
        bind = inds(I);
        
        %make variable to store the traces
        allEpochs = zeros(length(bind),epochlength+80);
        for mm = 1:length(bind)
            i_beginingOfTrace = bind(mm) -40;
            i_endOfTrace = bind(mm) + epochlength-1 + 40;
            % extract full part of the trace that we want, includes prior zero
            % period, the actuall epoch and following zero period
            try
                bl = mean(iratio(i_beginingOfTrace+20:i_beginingOfTrace+40));
                temp = (iratio(i_beginingOfTrace:i_endOfTrace) - bl) ./ bl;
            catch
                temp = NaN(1,epochlength+80);
            end

            
            allEpochs(mm,:) = temp;

            

        end
        roi_resps(jj,:) = nanmean(allEpochs,1);
    end
    
    max_resp = max(max(roi_resps,[],2));
    if max_resp < 0.4
        continue
    end
    
%     plot(d_iratio)
%     hold on;
%     plot(s)
%     w = waitforbuttonpress;
%     close all

%     plot(roi_resps')
%     w = waitforbuttonpress;
%     close all
    
    
    responses(goodROI,:,:) = roi_resps;
    
    
    name{goodROI}=in(iROI).name;
   
    if isfield(in,'cellNumber')
        cellNumber(goodROI) = in(iROI).cellNumber;
    end
   
    if isfield(in,'layer')
        layers(goodROI) = in(iROI).layer;
    end
    flyIDs(goodROI) = in(iROI).flyID;
    goodROI = goodROI + 1;

end   

if isfield(in,'categoryLabels')
    out.categoryLabels = in.categoryLabels;
end
if isfield(in,'cellNumber')
    out.cellNumber = cellNumber;
end
if isfield(in,'ROIsCategory')
    out.ROIsCategory = in.ROIsCategory;
end
if isfield(in,'layer')
    out.layer = layers;
end

responses = responses(1:goodROI-1,:,:);
out.responses = responses;
out.flyID = flyIDs;
fprintf('Pass ratio: %.2f', (goodROI-1)/iROI)
% No baseline substraction


%% first calculate the single values of efficiency
clearvars
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3rescue_on13double_100%_ND0.9_160dps.mat')
L3rescue=groupMeanperFly;
L3rescueMean=groupMean;
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3_heteroControl_on13double_100%_ND0.9_160dps.mat')
L3hetero=groupMeanperFly;
L3heteroMean=groupMean;
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1rescue_on13double_100%_ND0.9_160dps.mat')
L1rescue=groupMeanperFly;
L1rescueMean=groupMean;
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1_heteroControl_on13double_100%_ND0.9_160dps.mat')
L1hetero=groupMeanperFly;
L1heteroMean=groupMean;
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\ort1_Def_negControl_on13double_100%_ND0.9_160dps.mat')
negControl=groupMeanperFly;
negControlMean=groupMean;

effisL3=(L3rescueMean-negControlMean)./(L3heteroMean-negControlMean);
effisL1=(L1rescueMean-negControlMean)./(L1heteroMean-negControlMean);

figure; hold on
maxL=1176758.88;
edgeLs=[maxL*1/15,maxL*2/15,maxL*4/15,maxL*8/15,maxL*15/15]/8;
plot(edgeLs,effisL1,'-ob');
plot(edgeLs,effisL3,'-og');
xlim([8*10^3 2*10^5])
set(gca,'XScale','log')
xlabel('Background luminance (photons s^-^1 receptor^-^1)','FontSize',10,'FontName','Arial')
ylabel('rescue efficiencies','FontSize',10,'FontName','Arial')
title('rescue efficiencies')
ylim([0 1.4])
set(gca,'tickdir','out')
set(gca,'ticklength',[0.02 0.025])

%% Permutation test
uniqueDiffs=effisL3-effisL1; %the real difference

reps=3000;
combiSet=[L1rescue;L3rescue];
effiDiff=zeros(reps,5);
for i=1:reps
    iSeq=randperm(20);
    L3Set=combiSet(iSeq(1:10),:);
    L1Set=combiSet(iSeq(11:20),:);
    L3mean=mean(L3Set,1);
    L1mean=mean(L1Set,1);
    effiDiff(i,:)=L3mean-L1mean;
end

boundaries=zeros(5,2);
figure;
for iStim=1:5
    model=fitdist(effiDiff(:,iStim),'normal');
    boundaries(iStim,1)=model.mu - 3*model.sigma; % for 0.99% lower interval
    boundaries(iStim,2)=model.mu + 3*model.sigma; % for 0.99% upper interval
    subplot(1,5,iStim)
    hold on
    histfit(effiDiff(:,iStim),50);
    ylim([0 200]);
    xlim([-0.75,0.75]);
    xlabel('difference in efficiency (fraction)')
    ylabel('counts')
    line([boundaries(iStim,1),boundaries(iStim,1)],[0,200],'color','r');
    line([boundaries(iStim,2),boundaries(iStim,2)],[0,200],'color','r');
    line([uniqueDiffs(iStim),uniqueDiffs(iStim)],[0,200],'color','g');
    
%     [N,edges]=histcounts(effiDiff(:,iStim),50);
%     sumN=cumsum(N); %old primitive way
%     lessthan5=(sumN<reps*0.05);
%     lessthan5diff=diff(lessthan5);
%     ind5=find(lessthan5diff~=0)+1;
%     boundaries(iStim,1)=edges(ind5+1);
%     
%     lessthan1=(sumN<reps*0.01);
%     lessthan1diff=diff(lessthan1);
%     ind1=find(lessthan1diff~=0)+1;
%     boundaries(iStim,2)=edges(ind1+1);
end
%% bootstrapping to show the differences betwen L1 and L3 ON rescue
nSamples=100;sampleSize=5;
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3rescue_on13double_100%_ND0.9_160dps.mat')
bootMeansL3rescue=bootstrp(nSamples,@mean,groupMeanperFly);
% bootMeansL3rescue=zeros(nSamples,size(groupMeanperFly,2));
% for i=1:nSamples
%     thisSample=randi(size(groupMeanperFly,1),sampleSize);
%     bootMeansL3rescue(i,:)=mean(groupMeanperFly(thisSample,:));
% end

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3_heteroControl_on13double_100%_ND0.9_160dps.mat')
bootMeansL3control=bootstrp(nSamples,@mean,groupMeanperFly);
% bootMeansL3control=zeros(nSamples,size(groupMeanperFly,2));
% for i=1:nSamples
%     thisSample=randi(size(groupMeanperFly,1),sampleSize);
%     bootMeansL3control(i,:)=mean(groupMeanperFly(thisSample,:));
% end

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1rescue_on13double_100%_ND0.9_160dps.mat')
bootMeansL1rescue=bootstrp(nSamples,@mean,groupMeanperFly);
% bootMeansL1rescue=zeros(nSamples,size(groupMeanperFly,2));
% for i=1:nSamples
%     thisSample=randi(size(groupMeanperFly,1),sampleSize);
%     bootMeansL1rescue(i,:)=mean(groupMeanperFly(thisSample,:));
% end

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1_heteroControl_on13double_100%_ND0.9_160dps.mat')
bootMeansL1control=bootstrp(nSamples,@mean,groupMeanperFly);
% bootMeansL1control=zeros(nSamples,size(groupMeanperFly,2));
% for i=1:nSamples
%     thisSample=randi(size(groupMeanperFly,1),sampleSize);
%     bootMeansL1control(i,:)=mean(groupMeanperFly(thisSample,:));
% end

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\ort1_Def_negControl_on13double_100%_ND0.9_160dps.mat')
bootMeansNegcontrol=bootstrp(nSamples,@mean,groupMeanperFly);
% bootMeansNegcontrol=zeros(nSamples,size(groupMeanperFly,2));
% for i=1:nSamples
%     thisSample=randi(size(groupMeanperFly,1),sampleSize);
%     bootMeansNegcontrol(i,:)=mean(groupMeanperFly(thisSample,:));
% end

effisL3=zeros(nSamples,5);
effisL1=zeros(nSamples,5);
for i=1:nSamples
    effisL3(i,:)=(bootMeansL3rescue(i,:)-bootMeansNegcontrol(i,:))./(bootMeansL3control(i,:)-bootMeansNegcontrol(i,:));
    effisL1(i,:)=(bootMeansL1rescue(i,:)-bootMeansNegcontrol(i,:))./(bootMeansL1control(i,:)-bootMeansNegcontrol(i,:));
end

figure; hold on
errorbar([1 2 4 8 15],mean(effisL1),std(effisL1)./sqrt(length(effisL1)),'-ob');
errorbar([1 2 4 8 15],mean(effisL3),std(effisL3)./sqrt(length(effisL3)),'-og');
xlim([0 16])
xlabel('LED levels')
ylabel('rescue efficiencies')
title('rescue efficiencies after bootstrapping')
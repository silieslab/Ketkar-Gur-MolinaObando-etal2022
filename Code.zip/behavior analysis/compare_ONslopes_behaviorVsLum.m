%% first fit a line to the linear data
x=[1,2,4,8,15];%100%ON LED values as representative of luminance
%for L1 silencing
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_100%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig1=figure; hold on
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_Gal4_on13double_100%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig1);hold on
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'sm')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_shi_on13double_100%_ND0.9_160dps.mat')
slopesL1=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1(iFly)=fitModel.p1;
end
figure(fig1);hold on
errorbar(3,mean(slopesL1),std(slopesL1)/sqrt(10),'sb')
ylim([-0.04 0]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L1-Gal4/+','L1>>shi^t^s'})
title('slope of the 100%ON responses')
ylabel('slope (rad s^-^1 LED^-^1)')

%for L3 silencing
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_100%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig2=figure; hold on
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_Gal4_on13double_100%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig2);hold on
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'sm')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_shi_on13double_100%_ND0.9_160dps.mat')
slopesL3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL3(iFly)=fitModel.p1;
end
figure(fig2);hold on
errorbar(3,mean(slopesL3),std(slopesL3)/sqrt(10),'sb')
ylim([-0.04 0.01]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L3-Gal4/+','L3>>shi^t^s'})
title('slope of the 100%ON responses')
ylabel('slope (rad s^-^1 LED^-^1)')

x=[3,6,9,12,15];%50%ON, LED values ON edge
%for L1 silencing
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_50%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig3=figure; hold on
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_Gal4_on13double_50%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig3);hold on
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'sm')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_shi_on13double_50%_ND0.9_160dps.mat')
slopesL1=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1(iFly)=fitModel.p1;
end
figure(fig3);hold on
errorbar(3,mean(slopesL1),std(slopesL1)/sqrt(10),'sb')
ylim([-0.04 0]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L1-Gal4/+','L1>>shi^t^s'})
title('slope of the 50%ON responses')
ylabel('slope (rad s^-^1 LED^-^1)')

%for L3 silencing
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_50%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig4=figure; hold on
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_Gal4_on13double_50%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig4);hold on
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'sm')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_shi_on13double_50%_ND0.9_160dps.mat')
slopesL3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL3(iFly)=fitModel.p1;
end
figure(fig4);hold on
errorbar(3,mean(slopesL3),std(slopesL3)/sqrt(10),'sg')
ylim([-0.04 0.01]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L3-Gal4/+','L3>>shi^t^s'})
title('slope of the 50%ON responses')
ylabel('slope (rad s^-^1 LED^-^1)')

%% now fit to the log luminance, but normalize behavior data
maxL=1176758.88;
edgeLs=[maxL*1/15,maxL*2/15,maxL*4/15,maxL*8/15,maxL*15/15]/8; %100% edge luminances at ND 0.9
x=log10(edgeLs); %log luminance axis
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_100%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    yNorm=y/max(y);
    yNorm
    fitModel=fit(x',yNorm','poly1');
    slopesShi(iFly)=fitModel.p1;
end
figure; hold on
bar(1,mean(slopesShi))
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'k')
%% now fit to the log luminance
maxL=1176758.88;
edgeLs=[maxL*1/15,maxL*2/15,maxL*4/15,maxL*8/15,maxL*15/15]/8; %100% edge luminances at ND 0.9
x=log10(edgeLs); %log luminance axis
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_100%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig5=figure; hold on
bar(1,mean(slopesShi))
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_Gal4_on13double_100%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig5);hold on
bar(2,mean(slopesGal4))
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_shi_on13double_100%_ND0.9_160dps.mat')
slopesL1=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1(iFly)=fitModel.p1;
end
figure(fig5);hold on
bar(3,mean(slopesL1))
errorbar(3,mean(slopesL1),std(slopesL1)/sqrt(10),'k')
% ylim([-0.04 0]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L1-Gal4/+','L1>>shi^t^s'})
title('slope of the 100%ON responses')
ylabel('slope (rad*receptor/photons')

%for L3 silencing
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_100%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig6=figure; hold on
bar(1,mean(slopesShi))
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_Gal4_on13double_100%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig6);hold on
bar(2,mean(slopesGal4))
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_shi_on13double_100%_ND0.9_160dps.mat')
slopesL3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL3(iFly)=fitModel.p1;
end
figure(fig6);hold on
bar(3,mean(slopesL3))
errorbar(3,mean(slopesL3),std(slopesL3)/sqrt(10),'k')
% ylim([-0.04 0.01]);
xlim([0 4]);
set(gca,'XTick',1:3); 
set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L3-Gal4/+','L3>>shi^t^s'},'XTickLabelRotation',-40)
title('slope of the 100%ON responses')
ylabel('slope (rad*receptor/photons)')
    
edgeLs=[maxL*3/15,maxL*6/15,maxL*9/15,maxL*12/15,maxL*15/15]/8; %50% edge luminances at ND 0.9
x=log10(edgeLs); %log luminance axis
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_50%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig7=figure; hold on
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_Gal4_on13double_50%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig7);hold on
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'sm')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_shi_on13double_50%_ND0.9_160dps.mat')
slopesL1=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1(iFly)=fitModel.p1;
end
figure(fig7);hold on
errorbar(3,mean(slopesL1),std(slopesL1)/sqrt(10),'sb')
% ylim([-0.04 0]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L1-Gal4/+','L1>>shi^t^s'})
title('slope of the 50%ON responses')
ylabel('slope (rad*receptor/photons')

%for L3 silencing
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_50%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
fig8=figure; hold on
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(10),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_Gal4_on13double_50%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(fig8);hold on
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(10),'sm')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_shi_on13double_50%_ND0.9_160dps.mat')
slopesL3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL3(iFly)=fitModel.p1;
end
figure(fig8);hold on
errorbar(3,mean(slopesL3),std(slopesL3)/sqrt(10),'sb')
% ylim([-0.04 0.01]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L3-Gal4/+','L3>>shi^t^s'})
title('slope of the 50%ON responses')
ylabel('slope (rad(receptor/photons')

%% for L1-L3 silencing
maxL=1176758.88;
edgeLs=[maxL*1/15,maxL*2/15,maxL*4/15,maxL*8/15,maxL*15/15]/8; %100% edge luminances at ND 0.9
x=log10(edgeLs); %log luminance axis
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_100%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
figx=figure; hold on
bar(1,mean(slopesShi))
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(size(groupMeanperFly,1)),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1L3_Gal4_on13double_100%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(figx);hold on
bar(2,mean(slopesGal4))
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(size(groupMeanperFly,1)),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_shi_on13double_100%_ND0.9_160dps.mat')
slopesL3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL3(iFly)=fitModel.p1;
end
figure(figx);hold on
bar(3,mean(slopesL3))
errorbar(3,mean(slopesL3),std(slopesL3)/sqrt(10),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1L3_shi_on13double_100%_ND0.9_160dps.mat')
slopesL1=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1(iFly)=fitModel.p1;
end
figure(figx);hold on
bar(4,mean(slopesL1))
errorbar(4,mean(slopesL1),std(slopesL1)/sqrt(size(groupMeanperFly,1)),'k')
% ylim([-0.04 0]);
xlim([0 5]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L1L3-Gal4/+','L1L3>>shi^t^s'})
title('slope of the 100%ON responses')
ylabel('slope (rad*receptor/photons')
    
edgeLs=[maxL*3/15,maxL*6/15,maxL*9/15,maxL*12/15,maxL*15/15]/8; %50% edge luminances at ND 0.9
x=log10(edgeLs); %log luminance axis
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\UAS_shi_on13double_50%_ND0.9_160dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
figy=figure; hold on
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(size(groupMeanperFly,1)),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1L3_Gal4_on13double_50%_ND0.9_160dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(figy);hold on
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(size(groupMeanperFly,1)),'sm')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1L3_shi_on13double_50%_ND0.9_160dps.mat')
slopesL1L3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1L3(iFly)=fitModel.p1;
end
figure(figy);hold on
errorbar(3,mean(slopesL1L3),std(slopesL1L3)/sqrt(size(groupMeanperFly,1)),'sc')
% ylim([-0.04 0]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'UAS-shi^t^s/+','L1L3-Gal4/+','L1L3>>shi^t^s'})
title('slope of the 50%ON responses')
ylabel('slope (rad*receptor/photons')

% single silencing and double silencing together for 100%
maxL=1176758.88;
edgeLs=[maxL*1/15,maxL*2/15,maxL*4/15,maxL*8/15,maxL*15/15]/8; %100% edge luminances at ND 0.9
x=log10(edgeLs); %log luminance axis
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1[c202a]_shi_on13double_100%_ND0.9_160dps.mat')
slopesL1=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1(iFly)=fitModel.p1;
end
figz=figure; hold on
errorbar(1,mean(slopesL1),std(slopesL1)/sqrt(10),'sb')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L3[0595]_shi_on13double_100%_ND0.9_160dps.mat')
slopesL3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL3(iFly)=fitModel.p1;
end
figure(figz);hold on
errorbar(2,mean(slopesL3),std(slopesL3)/sqrt(size(groupMeanperFly,1)),'sg')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\L1L3_shi_on13double_100%_ND0.9_160dps.mat')
slopesL1L3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1L3(iFly)=fitModel.p1;
end
figure(figz);hold on
errorbar(3,mean(slopesL1L3),std(slopesL1L3)/sqrt(size(groupMeanperFly,1)),'sc')
% ylim([-0.04 0]);
xlim([0 4]);
set(gca,'XTick',1:3); set(gca, 'XTickLabel',{'L1>>shi^t^s','L3>>shi^t^s','L1L3>>shi^t^s'})
title('slope of the 100%ON responses')
ylabel('slope (rad*receptor/photons')

%% compare off slopes
maxL=1176758.88;
edgeLs=[maxL*1/15,maxL*2/15,maxL*4/15,maxL*8/15,maxL*15/15]/8; %100% edge luminances at ND 0.9
x=log10(edgeLs); %log luminance axis
load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp\UAS_shi_off_0toSteps_ND0.9_192dps.mat')
slopesShi=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesShi(iFly)=fitModel.p1;
end
figOFF=figure; hold on
bar(1,mean(slopesShi))
errorbar(1,mean(slopesShi),std(slopesShi)/sqrt(size(groupMeanperFly,1)),'k')

% load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp\UAS_shi_off_0toSteps_fromSebastian_ND0.9_192dps.mat')
% slopesShiSeb=zeros(size(groupMeanperFly,1),1);
% for iFly=1:size(groupMeanperFly,1)
%     y=groupMeanperFly(iFly,:);
%     fitModel=fit(x',y','poly1');
%     slopesShiSeb(iFly)=fitModel.p1;
% end
% figure(figOFF);hold on
% errorbar(2,mean(slopesShiSeb),std(slopesShiSeb)/sqrt(size(groupMeanperFly,1)),'sk')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp\L1[c202a]_Gal4_off_0toSteps_ND0.9_192dps.mat')
slopesGal4=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesGal4(iFly)=fitModel.p1;
end
figure(figOFF);hold on
bar(2,mean(slopesGal4))
errorbar(2,mean(slopesGal4),std(slopesGal4)/sqrt(size(groupMeanperFly,1)),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp\L3[0595]_shi_off_0toSteps_ND0.9_192dps.mat')
slopesL3=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL3(iFly)=fitModel.p1;
end
figure(figOFF);hold on
bar(3,mean(slopesL3))
errorbar(3,mean(slopesL3),std(slopesL3)/sqrt(size(groupMeanperFly,1)),'k')

load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp\L1_shi_off_0toSteps_ND0.9_192dps.mat')
slopesL1=zeros(size(groupMeanperFly,1),1);
for iFly=1:size(groupMeanperFly,1)
    y=groupMeanperFly(iFly,:);
    fitModel=fit(x',y','poly1');
    slopesL1(iFly)=fitModel.p1;
end
figure(figOFF);hold on
bar(4,mean(slopesL1))
errorbar(4,mean(slopesL1),std(slopesL1)/sqrt(size(groupMeanperFly,1)),'k')

% load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp_baselineCorrected\L1L3_Gal4_off_0toSteps_fromSebastian_ND0.9_192dps.mat')
% slopesDoubleGal4=zeros(size(groupMeanperFly,1),1);
% for iFly=1:size(groupMeanperFly,1)
%     y=groupMeanperFly(iFly,:);
%     fitModel=fit(x',y','poly1');
%     slopesDoubleGal4(iFly)=fitModel.p1;
% end
% figure(figOFF);hold on
% errorbar(5,mean(slopesDoubleGal4),std(slopesDoubleGal4)/sqrt(size(groupMeanperFly,1)),'sy')
% 
% load('Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp_baselineCorrected\L1L3_shi_off_0toSteps_fromSebastian_ND0.9_192dps.mat')
% slopesL1L3=zeros(size(groupMeanperFly,1),1);
% for iFly=1:size(groupMeanperFly,1)
%     y=groupMeanperFly(iFly,:);
%     fitModel=fit(x',y','poly1');
%     slopesL1L3(iFly)=fitModel.p1;
% end
% figure(figOFF);hold on
% errorbar(6,mean(slopesL1L3),std(slopesL1L3)/sqrt(size(groupMeanperFly,1)),'sc')
% % ylim([-0.04 0]);
% xlim([0 7]);
% set(gca,'XTick',1:6); set(gca, 'XTickLabel',{'UAS-shibire^m^k','UAS-shibire^s^e^b',...
%     'L1-Gal4/+','L1>>shi^t^s','L1L3-Gal4/+','L1L3>>shi^t^s'},'XTickLabelRotation',-40)
% title('slope of the 100%OFF responses')
% ylabel('slope (rad*receptor/photons')
function []=calculate_peak_velocities_mk(flydata,condition,stimStart,motionStart,durMotion)
%flydata is a 1Xn struct array with n=#flies.
%length(flydata(1).pdata.acc_dtheta) is the #groups (number of different stimuli)
%peakVelsperFlyperGroup are peak velocities for every instance before averaging
%baseline is per group (same for each fly) based on static duration(+100 ms delay) 
%12.02.19: peakVelsperFlyperGroup was modified to contain mean of 8 highest velocity points in each trial, because each trial can be noisy
%20.03.20: baseline correction was incorporated here instead of running the 'correct_baseline' function separately later on.

baselineDuration=0.2;

peakVelsperFlyperGroup=cell(size(flydata,2),length(flydata(1).pdata.acc_dtheta));
groupMeanperFly=zeros(size(flydata,2),length(flydata(1).pdata.acc_dtheta));
baselineVels=zeros(size(flydata,2),length(flydata(1).pdata.acc_dtheta)); %these do not consider baselineDuration
for i=1:length(flydata(1).pdata.acc_dtheta) % number of groups
    for j=1:size(flydata,2) %number of flies
        baselineVels(j,i)=mean(flydata(j).pdata.acc_dtheta{i}...
            (:,(round((0.1+motionStart)*120)-1)));
        dataSorted=sort(flydata(j).pdata.acc_dtheta{i}...
            (:,round((0.1+motionStart)*120):round((0.1+motionStart+durMotion)*120)),2,'descend');
        peakVelsperFlyperGroup{j,i}=mean(dataSorted(:,1:8),2);
        groupMeanperFly(j,i)=max(mean(flydata(j).pdata.acc_dtheta{i}...
            (:,round((0.1+motionStart)*120):round((0.1+motionStart+durMotion)*120)),1));
        groupMeanperFlyBaseline(j,i)=max(mean(flydata(j).pdata.acc_dtheta{i}(:,1:round(baselineDuration*120)),1));
    end
end
groupMean=mean(groupMeanperFly); %mean across all flies
groupSEM=std(groupMeanperFly)/sqrt(length(flydata));
% % one way of baseline correction
% blCorrected=groupMeanperFly-baselineVels*durMotion;
% groupMeanCorrected=mean(blCorrected);
% groupSEMCorrected=std(blCorrected)/sqrt(length(flydata));

% % another way (SEM will remain the same)
% groupMeanCorrected=groupMean-mean(baselineVels)*durMotion;

% % chosen way
GMPFcorrected=groupMeanperFly-groupMeanperFlyBaseline; %GMPF=groupMeanperFly

groupMeanCorrected=mean(GMPFcorrected); %mean across all flies
groupSEMcorrected=std(GMPFcorrected)/sqrt(length(flydata));

creationTimes=zeros(length(flydata),1);
for iFly=1:length(flydata)
    creationTimes(iFly)=flydata(iFly).data.creationTime; 
end

%store peak velocities together with stims in the order of stims
for iFly=1:size(flydata,2)
    %first, make a concatenated array of group inds (1 to 5)
    groupInds=[];
    for iGroup=1:length(flydata(1).pdata.acc_dtheta)
        groupInds=[groupInds; repmat(iGroup,length(flydata(iFly).pdata.stimstartsbytype{iGroup}),1)];
    end
    stimStartsAll=cat(2,flydata(iFly).pdata.stimstartsbytype{1:end});
    stimStartsWithInds=[stimStartsAll',groupInds];
    [stimStartsSorted,sortInds]=sortrows(stimStartsWithInds);
    stimIndsSorted{iFly}=stimStartsSorted(:,2);
    peakVelsAll=cat(1,peakVelsperFlyperGroup{iFly,1:end});
    peakVelsSorted{iFly}=peakVelsAll(sortInds);
    
    signsAll=cat(2,flydata(iFly).pdata.stimsignsbytype{1:end});
    stimSignsSorted{iFly}=signsAll(sortInds)';
end

% save(['/Users/madhura.ketkar/Desktop/Madhura/Matlab_FlyOnBall_copy/Matlab Auswertung neu/integratedTurns_shibire_Off96amp/',condition,'.mat'],...
%     'groupMean','groupSEM','groupMeanperFly','totalTurnsperFlyperGroup','baselineVels',...
%     'groupMeanCorrected','groupSEMcorrected','GMPFcorrected','creationTimes','groupMeanperFlyBaseline');

% save(['C:\Users\mdketkar\Documents\behavior\peakVels_shibire_Off96amp_baselineCorrected\50%Off\',condition,'.mat'],...
%     'groupMean','groupSEM','groupMeanperFly','baselineVels','groupMeanperFlyBaseline',...
%     'groupMeanCorrected','groupSEMcorrected','GMPFcorrected','creationTimes',...
%     'peakVelsSorted','stimIndsSorted','peakVelsSorted');

save(['Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\',condition,'.mat'],...
    'groupMean','groupSEM','groupMeanperFly','baselineVels','groupMeanperFlyBaseline',...
    'groupMeanCorrected','groupSEMcorrected','GMPFcorrected','creationTimes',...
    'peakVelsSorted','stimIndsSorted','peakVelsSorted');

end

    

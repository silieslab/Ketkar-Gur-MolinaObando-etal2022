    function []=plot_peakVelocities_mk(exptDescription,conditions)
    %% this function plots peak velocities of various genotypes to a class of stimuli 
    % also used to plot peak velocities. Switch loading path and title/ylabel for that purpose
    % the function will ask for x values and xlabel for the third plot, so that the xlabel can vary e.g. mean luminance/highest luminance/contrast 
    % conditions resemble the 'condition' input in 'calculate_integrated turns' e.g. L3_shits_offEdges_NDfilter
    % labels (xticklabels) resemble the different stimuli such as 0-1off
    % exptDescription is the common string at the end of integrated turns e.g. \_offEdges\_NDfilter
    
    maxL=1176758.88;
    edgeLs=[maxL*1/15,maxL*2/15,maxL*4/15,maxL*8/15,maxL*15/15]/8; %100% edge luminances at ND 0.9
%     edgeLs=[maxL*3/15,maxL*6/15,maxL*9/15,maxL*12/15,maxL*15/15]/8; %50% edge luminances at ND 0.9
    varyContrasts=[11,25,33,43,67,82,100]; %varying contrast, 10toON
%     varyContrasts=[9,18,27,36]; %varying contrast, 10toON
    % make customized color scheme
%     color1=[0 0 0; 0.15 0.15 0.15; 0.3 0.3 0.3; 0.45 0.45 0.45; 0.6 0.6 0.6; 0.75 0.75 0.75; 0.9 0.9 0.9]; %grey 7 
    color1=[0 0 0; 0.2 0.2 0.2; 0.4 0.4 0.4; 0.6 0.6 0.6; 0.8 0.8 0.8]; %grey
%     color2=[0.15 0.15 0.15; 0.3 0.3 0.3; 0.45 0.45 0.45; 0.6 0.6 0.6; 0.75 0.75 0.75; 0.9 0.9 0.9; 1 1 1]; %shifted grey 7
    color2=[0.2 0.2 0.2; 0.4 0.4 0.4; 0.6 0.6 0.6; 0.8 0.8 0.8; 0.95 0.95 0.95]; %shifted grey
    color3=[0 0.2 0; 0 0.4 0; 0 0.6 0; 0 0.8 0; 0 1 0]; % green
%     color3=[0 0.15 0; 0 0.3 0; 0 0.45 0; 0 0.6 0; 0 0.75 0; 0 0.9 0; 0 1 0]; % green 7
%     color4=[0 0.15 0.15;0 0.3 0.3;0 0.45 0.45; 0 0.6 0.6; 0 0.75 0.75; 0 0.9 0.9; 0 1 1]; %cyan 7
%     color4=[0 0.2 0.2; 0 0.4 0.4; 0 0.6 0.6; 0 0.8 0.8; 0 1 1]; %cyan
    color5=[0.2 0.2 0; 0.4 0.4 0; 0.6 0.6 0; 0.8 0.8 0; 1 1 0]; %~yellow
    color6=[0 0 0.2; 0 0 0.4; 0 0 0.6; 0 0 0.8; 0 0 1]; %blue
%     color7=[0 0 0; 0.1 0 0.1; 0.2 0 0.2; 0.4 0 0.4; 0.6 0 0.6; 0.8 0 0.8; 1 0 1]; %magenta
    colors=cat(3,color1,color2,color3);
% colors=color1;
    
    for i = 1:length(conditions)
%         load(['/Users/madhura.ketkar/Desktop/Madhura/Matlab_FlyOnBall_copy/Matlab Auswertung neu/integratedTurns_ortRescue/' conditions{i} '.mat']);
%         load(['Y:\MadhuraK\Behavior\mk_analysis\peakVels_shibire_OFF96amp_baselineCorrected\' conditions{i} '.mat']);
%         load(['/Volumes/wfs/#Common/Behavior/mk_analysis/inteGratedTurns_ortRescue/' conditions{i} '.mat']);
         load(['Y:\MadhuraK\Behavior\mk_analysis\peakVels_on_baselineCorrected\' conditions{i} '.mat']);
%         ticks{i} = regexp(varargin{i},'\d.+','match');
        ticks1{i} = conditions{i};
        tick=regexp(ticks1{i},exptDescription,'split');
        ticks{i} = strrep(tick{1},'_','\_');
%         groupMean=groupMean/max(groupMean); %if you want to normalize
        if i==1
            dataMeans=groupMean;
            dataSEM=groupSEM;
        else
            dataMeans=[dataMeans;groupMean];
            dataSEM=[dataSEM;groupSEM];
        end
    end
       

 %% plot   
    figure; %lineplot of amplitudes
%     prompt = ['Enter ' nbars 'x values for lineplot in square brackets'];
%     x=input(prompt);
    x=edgeLs;
%     x=varyContrasts;
    hold on
    for i = 1:size(dataMeans,1)
        errorbar(x,dataMeans(i,:),dataSEM(i,:),'-o','color',colors(3,:,i),'LineWidth',1.2,'MarkerSize',5,...
            'MarkerEdgeColor',colors(3,:,i),'MarkerFaceColor',colors(3,:,i));
    end
    title([exptDescription]);
%     label=input('enter xlabel in quotes');
%     xlabel('Edge luminance (photons s^-^1 receptor^-^1)','FontSize',10,'FontName','Arial')
    xlabel('contrast (%)');
%     ylabel('Integrated turns (Radians)')
    ylabel('Peak velocities (rad/s)','FontSize',10,'FontName','Arial')
    legend(ticks(:))
    set(gca,'xscale','log')
    box off
    set(gca,'tickdir','out')
    set(gca,'ticklength',[0.02 0.025])
%     xlim([2*10^4 2*10^5])
    xlim([8*10^3 2*10^5]) %for 100%ON
%     set(gca, 'XTick', [1 2 3])
%     set(gca,'XTickLabel',ticks(:));

%     figure; %lineplot of amplitudes normalised to the biggest amplitude
%     prompt = ['Enter ' nbars 'x values for lineplot in square brackets'];
%     x=input(prompt);
%     hold on
%     for i = 1:size(dataMeans,1)
%         normDataMeans=dataMeans(i,:)./max(dataMeans(i,:));
%         errorbar(x,normDataMeans,dataSEM(i,:),'LineWidth',2);
%     end
%     title([exptDescription]);
%     label=input('enter xlabel in quotes');
%     xlabel(label,'FontSize',10,'FontName','Arial')
% %     ylabel('Integrated turns (Radians)')
%     ylabel('Peak velocities (rad/s)','FontSize',10,'FontName','Arial')
%     legend(ticks(:))
    
    end
    